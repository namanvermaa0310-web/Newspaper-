// SHAKE-256, variable-length output. Same 136-byte rate as SHA3-256, but
// domain-separation byte 0x1F instead of 0x06, and a squeeze phase that can
// emit more than one rate-block of output (permuting between blocks).
// Output is exposed as a byte-addressable memory (rd_addr/rd_data), the same
// style as ntt_engine's coeff_mem interface, since output can exceed a
// single fixed-width bus.
module shake256 #(
  parameter MAX_MSG_BYTES = 512,
  parameter MAX_OUT_BYTES = 272   // 2 squeeze blocks (136 bytes each)
) (
  input  wire        clk,
  input  wire        rst_n,
  input  wire        start,
  input  wire [9:0]  msg_len,
  input  wire [8:0]  wr_addr,
  input  wire [7:0]  wr_data,
  input  wire        wr_en,
  input  wire [9:0]  out_len,      // desired output length, <= MAX_OUT_BYTES
  output reg         busy,
  output reg         done,
  input  wire [9:0]  rd_addr,
  output wire [7:0]  rd_data
);
  localparam RATE_BYTES = 136;

  reg [7:0] msg_buf [0:MAX_MSG_BYTES-1];
  always @(posedge clk) begin
    if (wr_en) msg_buf[wr_addr] <= wr_data;
  end

  reg [7:0] out_mem [0:MAX_OUT_BYTES-1];
  assign rd_data = out_mem[rd_addr];

  reg  [9:0] msg_len_reg;
  reg  [9:0] out_len_reg;
  reg  [7:0] blk_idx;
  wire [9:0] total_padded_len = msg_len_reg + 10'd1 + 10'((RATE_BYTES-1));
  wire [7:0] num_blocks = total_padded_len / RATE_BYTES;

  reg [1599:0] sponge_state;

  // ---- Absorb: current input block bytes (domain sep 0x1F for SHAKE) ----
  wire [7:0] cur_block_byte [0:RATE_BYTES-1];
  genvar bi;
  generate
    for (bi = 0; bi < RATE_BYTES; bi = bi + 1) begin : padblk
      wire [10:0] gidx = blk_idx * RATE_BYTES + bi;
      wire is_last_block = (blk_idx == num_blocks - 8'd1);
      wire [7:0] raw =
        (gidx < {1'b0, msg_len_reg}) ? msg_buf[gidx[8:0]] :
        (gidx == {1'b0, msg_len_reg}) ? 8'h1F : 8'h00;   // SHAKE domain sep
      assign cur_block_byte[bi] =
        (is_last_block && (bi == RATE_BYTES-1)) ? (raw | 8'h80) : raw;
    end
  endgenerate

  wire [1087:0] cur_block_bits;
  generate
    for (bi = 0; bi < 17; bi = bi + 1) begin : lane_pack
      assign cur_block_bits[64*bi +: 64] =
        { cur_block_byte[8*bi+7], cur_block_byte[8*bi+6], cur_block_byte[8*bi+5], cur_block_byte[8*bi+4],
          cur_block_byte[8*bi+3], cur_block_byte[8*bi+2], cur_block_byte[8*bi+1], cur_block_byte[8*bi+0] };
    end
  endgenerate

  wire [1599:0] xored_state = sponge_state ^ {512'd0, cur_block_bits};

  // ---- Squeeze: unpack sponge_state's first RATE_BYTES bytes, LE per lane ----
  function automatic logic [7:0] lane_byte(input logic [1599:0] st, input int unsigned n);
    logic [63:0] lane;
    lane = st[64*(n/8) +: 64];
    lane_byte = lane[8*(n%8) +: 8];
  endfunction

  reg          f_start;
  reg  [1599:0] f_state_in;
  wire [1599:0] f_state_out;
  wire         f_busy, f_done;

  keccak_f1600 u_f1600 (
    .clk(clk), .rst_n(rst_n), .start(f_start),
    .state_in(f_state_in), .state_out(f_state_out),
    .busy(f_busy), .done(f_done)
  );

  localparam ST_IDLE   = 3'd0, ST_XOR = 3'd1, ST_KICK = 3'd2, ST_RUN = 3'd3,
             ST_SQUEEZE= 3'd4, ST_SQKICK = 3'd5, ST_SQRUN = 3'd6, ST_DONE = 3'd7;
  reg [2:0] state;

  reg [9:0] out_written;   // bytes written to out_mem so far
  integer   wi;

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= ST_IDLE; busy <= 1'b0; done <= 1'b0; f_start <= 1'b0;
      f_state_in <= 1600'd0; sponge_state <= 1600'd0;
      blk_idx <= 8'd0; msg_len_reg <= 10'd0; out_len_reg <= 10'd0;
      out_written <= 10'd0;
    end else begin
      f_start <= 1'b0;
      case (state)
        ST_IDLE, ST_DONE: begin
          if (state == ST_DONE) done <= 1'b1;
          if (start) begin
            msg_len_reg  <= msg_len;
            out_len_reg  <= out_len;
            blk_idx      <= 8'd0;
            sponge_state <= 1600'd0;
            out_written  <= 10'd0;
            busy         <= 1'b1;
            done         <= 1'b0;
            state        <= ST_XOR;
          end
        end
        // -- absorb --
        ST_XOR: begin
          f_state_in <= xored_state;
          f_start    <= 1'b1;
          state      <= ST_KICK;
        end
        ST_KICK: state <= ST_RUN;
        ST_RUN: begin
          if (f_done) begin
            sponge_state <= f_state_out;
            if (blk_idx == num_blocks - 8'd1) begin
              state <= ST_SQUEEZE;   // absorb done, start squeezing
            end else begin
              blk_idx <= blk_idx + 8'd1;
              state   <= ST_XOR;
            end
          end
        end
        // -- squeeze: copy up to RATE_BYTES bytes from sponge_state into
        //    out_mem, then permute again if more output is still needed --
        ST_SQUEEZE: begin
          for (wi = 0; wi < RATE_BYTES; wi = wi + 1) begin
            if (out_written + wi[9:0] < out_len_reg)
              out_mem[out_written + wi[9:0]] <= lane_byte(sponge_state, wi);
          end
          if (out_written + RATE_BYTES[9:0] >= out_len_reg) begin
            out_written <= out_len_reg;
            busy  <= 1'b0;
            done  <= 1'b1;
            state <= ST_DONE;
          end else begin
            out_written <= out_written + RATE_BYTES[9:0];
            f_state_in  <= sponge_state;
            f_start     <= 1'b1;
            state       <= ST_SQKICK;
          end
        end
        ST_SQKICK: state <= ST_SQRUN;
        ST_SQRUN: begin
          if (f_done) begin
            sponge_state <= f_state_out;
            state <= ST_SQUEEZE;
          end
        end
        default: state <= ST_IDLE;
      endcase
    end
  end
endmodule : shake256
