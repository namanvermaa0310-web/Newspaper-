// SHA3-256, multi-block. Supports messages up to MAX_MSG_BYTES.
// Absorbs one 136-byte rate block at a time through keccak_f1600, looping
// until all (padded) blocks are consumed, then squeezes the first 32 bytes.
module sha3_256_mb #(
  parameter MAX_MSG_BYTES = 512
) (
  input  wire        clk,
  input  wire        rst_n,
  input  wire        start,
  input  wire [9:0]  msg_len,     // 0 .. MAX_MSG_BYTES
  input  wire [8:0]  wr_addr,
  input  wire [7:0]  wr_data,
  input  wire        wr_en,
  output reg         busy,
  output reg         done,
  output reg  [255:0] hash_out
);
  localparam RATE_BYTES = 136;

  reg [7:0] msg_buf [0:MAX_MSG_BYTES-1];
  always @(posedge clk) begin
    if (wr_en) msg_buf[wr_addr] <= wr_data;
  end

  function automatic logic [63:0] swap_bytes(input logic [63:0] v);
    swap_bytes = { v[7:0], v[15:8], v[23:16], v[31:24],
                    v[39:32], v[47:40], v[55:48], v[63:56] };
  endfunction

  reg  [9:0] msg_len_reg;
  reg  [7:0] blk_idx;
  wire [9:0] total_padded_len = msg_len_reg + 10'd1 + 10'((RATE_BYTES-1));
  wire [7:0] num_blocks = total_padded_len / RATE_BYTES;  // ceil((len+1)/136)

  reg [1599:0] sponge_state;

  // Combinational: the 136 padded bytes of the CURRENT block (blk_idx),
  // built directly from msg_buf/msg_len_reg -- continuous-assign generate
  // pattern (not a procedural always@(*) over a memory array; see sha3_256.sv
  // for why that pattern silently fails to re-trigger under Icarus).
  wire [7:0] cur_block_byte [0:RATE_BYTES-1];
  genvar bi;
  generate
    for (bi = 0; bi < RATE_BYTES; bi = bi + 1) begin : padblk
      wire [10:0] gidx = blk_idx * RATE_BYTES + bi;
      wire is_last_block = (blk_idx == num_blocks - 8'd1);
      wire [7:0] raw =
        (gidx < {1'b0, msg_len_reg}) ? msg_buf[gidx[8:0]] :
        (gidx == {1'b0, msg_len_reg}) ? 8'h06 : 8'h00;
      assign cur_block_byte[bi] =
        (is_last_block && (bi == RATE_BYTES-1)) ? (raw | 8'h80) : raw;
    end
  endgenerate

  wire [1087:0] cur_block_bits;
  generate
    for (bi = 0; bi < 17; bi = bi + 1) begin : lane_pack
      assign cur_block_bits[64*bi +: 64] =
        { cur_block_byte[8*bi+7], cur_block_byte[8*bi+6], cur_block_byte[8*bi+5], cur_block_byte[8*bi+4],
          cur_block_byte[8*bi+3], cur_block_byte[8*bi+2], cur_block_byte[8*bi+1], cur_block_byte[8*bi+0] };
    end
  endgenerate

  wire [1599:0] xored_state = sponge_state ^ {512'd0, cur_block_bits};

  reg          f_start;
  reg  [1599:0] f_state_in;
  wire [1599:0] f_state_out;
  wire         f_busy, f_done;

  keccak_f1600 u_f1600 (
    .clk(clk), .rst_n(rst_n), .start(f_start),
    .state_in(f_state_in), .state_out(f_state_out),
    .busy(f_busy), .done(f_done)
  );

  localparam ST_IDLE = 3'd0, ST_XOR = 3'd1, ST_KICK = 3'd2,
             ST_RUN  = 3'd3, ST_DONE = 3'd4;
  reg [2:0] state;

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= ST_IDLE; busy <= 1'b0; done <= 1'b0; f_start <= 1'b0;
      hash_out <= 256'd0; f_state_in <= 1600'd0; sponge_state <= 1600'd0;
      blk_idx <= 8'd0; msg_len_reg <= 10'd0;
    end else begin
      f_start <= 1'b0;
      case (state)
        ST_IDLE, ST_DONE: begin
          if (state == ST_DONE) done <= 1'b1;
          if (start) begin
            msg_len_reg  <= msg_len;
            blk_idx      <= 8'd0;
            sponge_state <= 1600'd0;
            busy         <= 1'b1;
            done         <= 1'b0;
            state        <= ST_XOR;
          end
        end
        ST_XOR: begin
          f_state_in <= xored_state;
          f_start    <= 1'b1;
          state      <= ST_KICK;
        end
        ST_KICK: state <= ST_RUN;  // buffer cycle; avoids stale f_done race
        ST_RUN: begin
          if (f_done) begin
            sponge_state <= f_state_out;
            if (blk_idx == num_blocks - 8'd1) begin
              hash_out <= { swap_bytes(f_state_out[64*0 +: 64]),
                            swap_bytes(f_state_out[64*1 +: 64]),
                            swap_bytes(f_state_out[64*2 +: 64]),
                            swap_bytes(f_state_out[64*3 +: 64]) };
              busy  <= 1'b0;
              done  <= 1'b1;
              state <= ST_DONE;
            end else begin
              blk_idx <= blk_idx + 8'd1;
              state   <= ST_XOR;
            end
          end
        end
        default: state <= ST_IDLE;
      endcase
    end
  end
endmodule : sha3_256_mb
