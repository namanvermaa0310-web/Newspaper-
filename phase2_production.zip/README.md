# Phase 2 Production: SHA3-256 / SHAKE-256 on KC705

Same architecture as Phases 1 and 3: the Keccak cores are reached over the
KC705's USB-UART bridge rather than raw pins, because a 512-byte message
buffer and a 256-bit digest have no honest mapping onto 8 LEDs and 4 DIP
switches.

## Verified
Icarus, driving real serial waveforms (no backdoor memory access), against
official FIPS 202 / NIST CAVP vectors:

    [TB] PING ok (link alive)
    [TB] SHA3(empty):          32/32 digest bytes match FIPS 202
    [TB] SHA3(abc):            32/32 digest bytes match FIPS 202
    [TB] SHAKE(mt):            32/32 output bytes checked
    [TB] SHAKE(abc):           32/32 output bytes checked
    [TB] SHA3(200B multiblk):  32/32 digest bytes match FIPS 202
    [TB] SHAKE(abc,200)@136:   32/32 bytes past rate boundary checked
    PASS -- SHA3-256 and SHAKE-256 verified over the UART path

The last two matter most. The rate is 136 bytes, so the short vectors only ever
exercise a single absorb block and a single squeeze block. The 200-byte message
forces a **second absorb block**, and reading SHAKE output at offset 136 forces
a **second squeeze block** (the sponge must permute again between blocks).
Passing the short vectors tells you nothing about either loop.

Vectors used:
    SHA3-256("")        a7ffc6f8bf1ed76651c14756a061d662f580ff4de43b49fa82d80a4b80f8434a
    SHA3-256("abc")     3a985da74fe225b2045c172d6bd390bd855f086e3e9d525b46bfe24511431532
    SHA3-256(0..199)    5f728f63bf5ee48c77f453c0490398fa645b8d4c4e56be9a41cfec344d6ca899
    SHAKE256("",32)     46b9dd2b0ba88d13233b3feb743eeb243fcd52ea62b81b82b50c27646ed5762f
    SHAKE256("abc",32)  483366601360a8771c6863080cc4114d8db44530f8f1e1ee4f94ea37e78b5739
    SHAKE256("abc",200) bytes 136..167: cf0ea610eeff1a588290a53000faa79932becec0bd3cd0b33a7e5d397fed1ada

## Files (13)
| File | Role | Simulated? |
|---|---|---|
| keccak_pkg.sv | 24 round constants, rho rotation offsets | yes |
| keccak_round.sv | one Keccak-f round: theta, rho+pi, chi, iota | yes |
| keccak_f1600.sv | 24-round permutation FSM | yes |
| sha3_256.sv | multi-block sponge, rate 136, domain 0x06 (module: `sha3_256_mb`) | yes |
| shake256.sv | variable-output XOF, rate 136, domain 0x1F | yes |
| uart_rx.sv, uart_tx.sv | 8N1 serial (identical to Phases 1/3) | yes |
| keccak_uart_core.sv | command FSM, board-independent | yes |
| kc705_keccak_top.sv | IBUFDS + MMCM + reset sync | no -- Vivado only |
| tb_keccak_uart_core.sv | end-to-end serial testbench | -- |
| kc705_keccak.xdc | same 4 verified pins as Phases 1/3 | -- |
| host_keccak.py | PC-side bench driver | -- |

## Command protocol
| Bytes (host -> FPGA) | Meaning | Reply |
|---|---|---|
| `A5` | ping | `5A` |
| `30 a_lo a_hi data` | SHA3: write message byte | `30` |
| `31 len_lo len_hi` | SHA3: start | `31` |
| `32` | SHA3: status | `{6'b0,done,busy}` |
| `33 idx` | SHA3: read digest byte (0..31) | byte |
| `40 a_lo a_hi data` | SHAKE: write message byte | `40` |
| `41 ml_lo ml_hi ol_lo ol_hi` | SHAKE: start | `41` |
| `42` | SHAKE: status | `{6'b0,done,busy}` |
| `43 i_lo i_hi` | SHAKE: read output byte | byte |

Digest byte 0 is the MOST significant byte, matching the usual convention
SHA3-256("") = a7ffc6f8...

Buffer limits are set by the RTL parameters: `MAX_MSG_BYTES = 512`,
`MAX_OUT_BYTES = 272`. `host_keccak.py` enforces both.

## Complete steps

### 1. Simulate first (Vivado XSim)
1. New project, part `xc7k325tffg900-2`
2. Design sources: `keccak_pkg.sv`, `keccak_round.sv`, `keccak_f1600.sv`,
   `sha3_256.sv`, `shake256.sv`, `uart_rx.sv`, `uart_tx.sv`,
   `keccak_uart_core.sv`, `kc705_keccak_top.sv`
3. Simulation source: `tb_keccak_uart_core.sv`
4. Constraints: `kc705_keccak.xdc`
5. Set `tb_keccak_uart_core` as **simulation** top
6. Run Behavioral Simulation, then in the Tcl console: `run 5ms`
   (the 1 us default is far too short -- this bit-bangs real UART)
7. Expect the PASS banner above

No `.hex` files are needed for Phase 2 -- the vectors are compiled into the
testbench as constants.

### 2. Synthesis and implementation
1. Set `kc705_keccak_top` as **design** top
2. Run Synthesis
3. Run Implementation
4. **Report Timing Summary -- confirm WNS is positive before going further**

### 3. Bitstream and board
1. Generate Bitstream
2. Power the KC705 (12 V adapter -- it is not USB powered)
3. Connect both USB cables: JTAG, and the separate USB UART (mini-B,
   Silicon Labs CP2103, needs the CP210x VCP driver)
4. Hardware Manager -> Open Target -> Auto Connect -> Program Device
5. DONE LED should light

### 4. Bench test
    py -m pip install pyserial
    py host_keccak.py COM6

Substitute your COM port (Device Manager -> Ports). Expect six PASS lines and:

    PASS -- hardware Keccak matches FIPS 202
    SHA3-256 and SHAKE-256 correct on real silicon,
    including multi-block absorb and multi-block squeeze

## Timing expectation -- check, do not assume
Phase 1 needed three rounds of pipelining to close timing, so this is worth
taking seriously rather than assuming Keccak is easy.

Keccak has a different profile: no multipliers, just XOR, rotate and AND. But
`keccak_round` computes an entire round -- theta, rho+pi, chi, iota over the
full 1600-bit state -- combinationally, and `keccak_f1600` runs one round per
cycle. That is a **wide, shallow** path rather than a deep one, and it may
still be tight at 100 MHz.

**Check WNS after implementation before generating a bitstream.** If negative,
split `keccak_round` so theta+rho+pi lands in one cycle and chi+iota in the
next, doubling the permutation from 24 to 48 cycles.

Do not resolve it with timing constraints. A multicycle-path exception would be
a lie to the timing engine here -- each stage's output is consumed on the very
next edge. Constraints change what the tool checks; pipelining changes the
actual circuit. Only the second one fixes a genuinely over-length path, and a
design with negative slack programs fine and computes garbage while simulation
passes happily.

## Diagnosing a hardware failure
`host_keccak.py` orders its vectors so a failure localises itself:

- **All vectors wrong, short ones included** -> the Keccak-f[1600] permutation
  itself, or timing closure. Check WNS first.
- **Short vectors right, 200-byte ones wrong** -> the multi-block absorb loop
  (SHA3) or the multi-squeeze loop (SHAKE), not the permutation.
- **SHA3 right, SHAKE wrong** -> domain separation byte (0x06 vs 0x1F), or the
  squeeze path.
- **No PING reply at all** -> CPU_RESET polarity (the wrapper assumes active
  high), or the UART pin pair (Xilinx AR 45934 documents a K24/M19
  discrepancy).

## What this is
Two verified FIPS 202 primitives on real hardware. They are prerequisites for
ML-KEM, not ML-KEM itself: Phase 3 wires SHAKE-128 and SHAKE-256 into the
FIPS 203 samplers, and Phase 4 remains the full protocol.
