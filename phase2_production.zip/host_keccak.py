#!/usr/bin/env python3
"""
host_keccak.py -- host-side bench driver for the KC705 Keccak accelerator.

Drives the SHA3-256 and SHAKE-256 engines over the KC705's USB-UART bridge and
checks every output byte against Python's hashlib, which implements FIPS 202.

Test vectors are the official NIST/FIPS 202 ones plus a longer multi-block case
that forces the sponge to absorb more than one 136-byte rate block -- the
single-block path passing tells you nothing about the absorb loop.

Usage (Windows):
    py -m pip install pyserial
    py host_keccak.py COM6

Usage (Linux):
    python3 host_keccak.py /dev/ttyUSB0
"""

import sys
import time
import hashlib

try:
    import serial
except ImportError:
    sys.exit("pyserial not installed.  Run:  py -m pip install pyserial")

BAUD = 115200

C_PING   = 0xA5
PING_OK  = 0x5A
C_SHA_WR = 0x30
C_SHA_GO = 0x31
C_SHA_ST = 0x32
C_SHA_RD = 0x33
C_SHK_WR = 0x40
C_SHK_GO = 0x41
C_SHK_ST = 0x42
C_SHK_RD = 0x43

# Must match the RTL parameters in keccak_uart_core.sv
MAX_MSG = 512
MAX_OUT = 272


class Keccak:
    def __init__(self, port):
        self.ser = serial.Serial(port, BAUD, timeout=3.0)
        time.sleep(0.2)
        self.ser.reset_input_buffer()

    def _expect(self, want, what):
        got = self.ser.read(1)
        if not got:
            raise TimeoutError(f"{what}: no reply (timeout)")
        if got[0] != want:
            raise ValueError(f"{what}: got 0x{got[0]:02X}, expected 0x{want:02X}")

    def _read1(self, what):
        b = self.ser.read(1)
        if not b:
            raise TimeoutError(f"{what}: no reply (timeout)")
        return b[0]

    def ping(self, retries=3):
        # Opening a COM port toggles DTR/RTS on many USB-UART bridges, so the
        # very first byte can be lost while the link settles. Retry rather than
        # fail the run on a benign first miss.
        for attempt in range(retries):
            try:
                self.ser.reset_input_buffer()
                self.ser.write(bytes([C_PING]))
                self._expect(PING_OK, "PING")
                return attempt
            except (TimeoutError, ValueError):
                if attempt == retries - 1:
                    raise
                time.sleep(0.3)

    # ---- SHA3-256 ----------------------------------------------------------
    def sha3_load(self, msg):
        if len(msg) > MAX_MSG:
            raise ValueError(f"message too long: {len(msg)} > {MAX_MSG}")
        for i, b in enumerate(msg):
            self.ser.write(bytes([C_SHA_WR, i & 0xFF, (i >> 8) & 0xFF, b]))
            self._expect(C_SHA_WR, f"SHA3 WRITE[{i}]")

    def sha3_start(self, length):
        self.ser.write(bytes([C_SHA_GO, length & 0xFF, (length >> 8) & 0xFF]))
        self._expect(C_SHA_GO, "SHA3 START")

    def sha3_status(self):
        self.ser.write(bytes([C_SHA_ST]))
        b = self._read1("SHA3 STATUS")
        return {"busy": bool(b & 0x01), "done": bool(b & 0x02)}

    def sha3_wait(self, timeout_s=10.0):
        t0 = time.time()
        while time.time() - t0 < timeout_s:
            st = self.sha3_status()
            if not st["busy"] and st["done"]:
                return
        raise TimeoutError("SHA3-256 never reported done")

    def sha3_digest(self):
        out = bytearray()
        for i in range(32):
            self.ser.write(bytes([C_SHA_RD, i]))
            out.append(self._read1(f"SHA3 READ[{i}]"))
        return bytes(out)

    def sha3(self, msg):
        self.sha3_load(msg)
        self.sha3_start(len(msg))
        self.sha3_wait()
        return self.sha3_digest()

    # ---- SHAKE-256 ---------------------------------------------------------
    def shake_load(self, msg):
        if len(msg) > MAX_MSG:
            raise ValueError(f"message too long: {len(msg)} > {MAX_MSG}")
        for i, b in enumerate(msg):
            self.ser.write(bytes([C_SHK_WR, i & 0xFF, (i >> 8) & 0xFF, b]))
            self._expect(C_SHK_WR, f"SHAKE WRITE[{i}]")

    def shake_start(self, msg_len, out_len):
        if out_len > MAX_OUT:
            raise ValueError(f"output too long: {out_len} > {MAX_OUT}")
        self.ser.write(bytes([C_SHK_GO,
                              msg_len & 0xFF, (msg_len >> 8) & 0xFF,
                              out_len & 0xFF, (out_len >> 8) & 0xFF]))
        self._expect(C_SHK_GO, "SHAKE START")

    def shake_status(self):
        self.ser.write(bytes([C_SHK_ST]))
        b = self._read1("SHAKE STATUS")
        return {"busy": bool(b & 0x01), "done": bool(b & 0x02)}

    def shake_wait(self, timeout_s=10.0):
        t0 = time.time()
        while time.time() - t0 < timeout_s:
            st = self.shake_status()
            if not st["busy"] and st["done"]:
                return
        raise TimeoutError("SHAKE-256 never reported done")

    def shake_read(self, out_len):
        out = bytearray()
        for i in range(out_len):
            self.ser.write(bytes([C_SHK_RD, i & 0xFF, (i >> 8) & 0xFF]))
            out.append(self._read1(f"SHAKE READ[{i}]"))
        return bytes(out)

    def shake(self, msg, out_len):
        self.shake_load(msg)
        self.shake_start(len(msg), out_len)
        self.shake_wait()
        return self.shake_read(out_len)


def check(label, got, want):
    if got == want:
        print(f"  PASS  {label}")
        print(f"        {got.hex()}")
        return 0
    print(f"  FAIL  {label}")
    print(f"        got  {got.hex()}")
    print(f"        want {want.hex()}")
    return 1


def main():
    if len(sys.argv) != 2:
        sys.exit(f"usage: {sys.argv[0]} <serial-port>")
    port = sys.argv[1]

    print(f"Opening {port} at {BAUD} baud...")
    k = Keccak(port)

    print("PING...", end=" ", flush=True)
    tries = k.ping()
    print("ok, link alive" + (f" (after {tries} retr{'y' if tries==1 else 'ies'})"
                              if tries else ""))
    print()

    errs = 0

    # ---- SHA3-256 ----------------------------------------------------------
    print("SHA3-256:")

    t0 = time.time()
    errs += check('SHA3-256("")', k.sha3(b""), hashlib.sha3_256(b"").digest())
    print(f"        ({(time.time()-t0)*1000:.0f} ms incl. UART)")

    errs += check('SHA3-256("abc")',
                  k.sha3(b"abc"), hashlib.sha3_256(b"abc").digest())

    # 200 bytes forces a second absorb block (rate is 136), which the short
    # vectors above never exercise.
    msg200 = bytes(range(200))
    errs += check("SHA3-256(200 bytes, multi-block)",
                  k.sha3(msg200), hashlib.sha3_256(msg200).digest())

    print()

    # ---- SHAKE-256 ---------------------------------------------------------
    print("SHAKE-256:")

    errs += check('SHAKE-256("", 32)',
                  k.shake(b"", 32), hashlib.shake_256(b"").digest(32))

    errs += check('SHAKE-256("abc", 32)',
                  k.shake(b"abc", 32), hashlib.shake_256(b"abc").digest(32))

    # 200 bytes of output needs a second squeeze block (rate 136), so this
    # exercises the permute-between-blocks path in the squeeze FSM.
    errs += check('SHAKE-256("abc", 200) multi-squeeze',
                  k.shake(b"abc", 200), hashlib.shake_256(b"abc").digest(200))

    print()
    print("=" * 60)
    if errs == 0:
        print("  PASS -- hardware Keccak matches FIPS 202")
        print("  SHA3-256 and SHAKE-256 correct on real silicon,")
        print("  including multi-block absorb and multi-block squeeze")
        print("=" * 60)
        return 0
    else:
        print(f"  FAIL -- {errs} vector(s) wrong")
        print("=" * 60)
        print("Diagnosis:")
        print("  Short vectors wrong, long ones too  -> the Keccak-f[1600]")
        print("    permutation itself, or timing closure. Check WNS first.")
        print("  Short vectors right, 200-byte wrong -> the multi-block")
        print("    absorb loop (SHA3) or multi-squeeze loop (SHAKE).")
        print("  SHA3 right, SHAKE wrong             -> domain separation")
        print("    byte (0x06 vs 0x1F) or the squeeze path.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
