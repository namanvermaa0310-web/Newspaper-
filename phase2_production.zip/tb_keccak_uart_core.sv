`timescale 1ns/1ps
// =============================================================================
// tb_keccak_uart_core.sv -- Phase 2 board-path test over real serial waveforms
// Golden vectors are the official FIPS 202 / NIST CAVP values:
//   SHA3-256("")      = a7ffc6f8bf1ed76651c14756a061d662f580ff4de43b49fa82d80a4b80f8434a
//   SHA3-256("abc")   = 3a985da74fe225b2045c172d6bd390bd855f086e3e9d525b46bfe24511431532
//   SHAKE256("",32)   = 46b9dd2b0ba88d13233b3feb743eeb243fcd52ea62b81b82b50c27646ed5762f
//   SHAKE256("abc",32)= 483366601360a8771c6863080cc4114d8db44530f8f1e1ee4f94ea37e78b5739
// =============================================================================
module tb_keccak_uart_core;
  localparam integer CPB = 16;
  reg clk = 0, rst_n = 0;
  reg  host_tx = 1'b1;
  wire fpga_tx;

  keccak_uart_core #(.CLKS_PER_BIT(CPB)) dut (
    .clk(clk), .rst_n(rst_n), .uart_rx_i(host_tx), .uart_tx_o(fpga_tx)
  );
  always #5 clk = ~clk;

  integer errors = 0;
  integer k;
  reg [7:0] got;
  reg [255:0] exp_sha, exp_shk;

  task host_send(input [7:0] b);
    integer i;
    begin
      host_tx = 1'b0; repeat (CPB) @(posedge clk);
      for (i=0;i<8;i=i+1) begin host_tx=b[i]; repeat(CPB) @(posedge clk); end
      host_tx = 1'b1; repeat (CPB) @(posedge clk);
    end
  endtask

  reg [7:0] rxq [0:8191];
  integer rxq_wr = 0, rxq_rd = 0;
  initial begin : mon
    reg [7:0] b; integer i;
    forever begin
      @(negedge fpga_tx);
      repeat (CPB + CPB/2) @(posedge clk);
      for (i=0;i<8;i=i+1) begin
        b[i] = fpga_tx;
        if (i<7) repeat(CPB) @(posedge clk);
      end
      rxq[rxq_wr]=b; rxq_wr=rxq_wr+1;
      repeat (CPB) @(posedge clk);
    end
  end
  task host_recv(output [7:0] b);
    begin
      while (rxq_rd == rxq_wr) @(posedge clk);
      b = rxq[rxq_rd]; rxq_rd = rxq_rd + 1;
    end
  endtask

  // Run SHA3-256 over msg[0..len-1], compare 32-byte digest to `expect`
  task do_sha3(input integer len, input [255:0] expect_val, input [255:0] label);
    integer j; reg [7:0] r; reg [7:0] want;
    begin
      host_send(8'h31); host_send(len[7:0]); host_send({6'd0,len[9:8]});
      host_recv(r);
      r = 8'h01; j = 0;
      while (r[0]===1'b1 && j<500) begin host_send(8'h32); host_recv(r); j=j+1; end
      if (r[1] !== 1'b1) begin
        $display("[TB] FAIL %0s: never completed", label); errors=errors+1;
      end
      for (j=0;j<32;j=j+1) begin
        host_send(8'h33); host_send(j[7:0]); host_recv(r);
        want = expect_val[(31-j)*8 +: 8];
        if (r !== want) begin
          if (errors<8) $display("[TB] FAIL %0s digest[%0d]: got %02h want %02h", label, j, r, want);
          errors=errors+1;
        end
      end
      if (errors==0) $display("[TB] %0s: 32/32 digest bytes match FIPS 202", label);
    end
  endtask

  task do_shake(input integer mlen, input integer olen,
                input [255:0] expect_val, input [255:0] label);
    integer j; reg [7:0] r; reg [7:0] want;
    begin
      host_send(8'h41);
      host_send(mlen[7:0]); host_send({6'd0,mlen[9:8]});
      host_send(olen[7:0]); host_send({6'd0,olen[9:8]});
      host_recv(r);
      r = 8'h01; j = 0;
      while (r[0]===1'b1 && j<500) begin host_send(8'h42); host_recv(r); j=j+1; end
      if (r[1] !== 1'b1) begin
        $display("[TB] FAIL %0s: never completed", label); errors=errors+1;
      end
      for (j=0;j<32;j=j+1) begin
        host_send(8'h43); host_send(j[7:0]); host_send(8'h00); host_recv(r);
        want = expect_val[(31-j)*8 +: 8];
        if (r !== want) begin
          if (errors<8) $display("[TB] FAIL %0s out[%0d]: got %02h want %02h", label, j, r, want);
          errors=errors+1;
        end
      end
      $display("[TB] %0s: 32/32 output bytes checked", label);
    end
  endtask

  // Run SHAKE and check 32 output bytes starting at `off` -- lets us verify
  // bytes past the 136-byte rate boundary, i.e. the multi-squeeze path.
  task do_shake_at(input integer mlen, input integer olen, input integer off,
                   input [255:0] expect_val, input [255:0] label);
    integer j; reg [7:0] r; reg [7:0] want; integer idx;
    begin
      host_send(8'h41);
      host_send(mlen[7:0]); host_send({6'd0,mlen[9:8]});
      host_send(olen[7:0]); host_send({6'd0,olen[9:8]});
      host_recv(r);
      r = 8'h01; j = 0;
      while (r[0]===1'b1 && j<500) begin host_send(8'h42); host_recv(r); j=j+1; end
      if (r[1] !== 1'b1) begin
        $display("[TB] FAIL %0s: never completed", label); errors=errors+1;
      end
      for (j=0;j<32;j=j+1) begin
        idx = off + j;
        host_send(8'h43); host_send(idx[7:0]); host_send({6'd0,idx[9:8]});
        host_recv(r);
        want = expect_val[(31-j)*8 +: 8];
        if (r !== want) begin
          if (errors<8) $display("[TB] FAIL %0s out[%0d]: got %02h want %02h", label, idx, r, want);
          errors=errors+1;
        end
      end
      $display("[TB] %0s: 32/32 bytes past rate boundary checked", label);
    end
  endtask

  initial begin
    $display("============================================================");
    $display("  Phase 2 UART board-path test: SHA3-256 + SHAKE-256");
    $display("============================================================");
    rst_n=0; repeat(10) @(posedge clk); rst_n=1; repeat(10) @(posedge clk);

    host_send(8'hA5); host_recv(got);
    if (got !== 8'h5A) begin $display("[TB] FAIL ping: %02h",got); errors=errors+1; end
    else $display("[TB] PING ok (link alive)");

    // ---- SHA3-256("") ----
    exp_sha = 256'ha7ffc6f8bf1ed76651c14756a061d662f580ff4de43b49fa82d80a4b80f8434a;
    do_sha3(0, exp_sha, "SHA3(empty)");

    // ---- SHA3-256("abc") ----
    host_send(8'h30); host_send(8'd0); host_send(8'd0); host_send("a"); host_recv(got);
    host_send(8'h30); host_send(8'd1); host_send(8'd0); host_send("b"); host_recv(got);
    host_send(8'h30); host_send(8'd2); host_send(8'd0); host_send("c"); host_recv(got);
    exp_sha = 256'h3a985da74fe225b2045c172d6bd390bd855f086e3e9d525b46bfe24511431532;
    do_sha3(3, exp_sha, "SHA3(abc)");

    // ---- SHAKE-256("", 32) ----
    exp_shk = 256'h46b9dd2b0ba88d13233b3feb743eeb243fcd52ea62b81b82b50c27646ed5762f;
    do_shake(0, 32, exp_shk, "SHAKE(mt)");

    // ---- SHAKE-256("abc", 32) ----
    host_send(8'h40); host_send(8'd0); host_send(8'd0); host_send("a"); host_recv(got);
    host_send(8'h40); host_send(8'd1); host_send(8'd0); host_send("b"); host_recv(got);
    host_send(8'h40); host_send(8'd2); host_send(8'd0); host_send("c"); host_recv(got);
    exp_shk = 256'h483366601360a8771c6863080cc4114d8db44530f8f1e1ee4f94ea37e78b5739;
    do_shake(3, 32, exp_shk, "SHAKE(abc)");

    // ---- SHA3-256(200 bytes) -- forces a SECOND absorb block (rate=136) ----
    for (k=0;k<200;k=k+1) begin
      host_send(8'h30); host_send(k[7:0]); host_send(8'd0); host_send(k[7:0]);
      host_recv(got);
    end
    exp_sha = 256'h5f728f63bf5ee48c77f453c0490398fa645b8d4c4e56be9a41cfec344d6ca899;
    do_sha3(200, exp_sha, "SHA3(200B multiblk)");

    // ---- SHAKE-256("abc", 200) -- forces a SECOND squeeze block ----
    // Message buffer already holds "abc" from the earlier SHAKE test.
    host_send(8'h40); host_send(8'd0); host_send(8'd0); host_send("a"); host_recv(got);
    host_send(8'h40); host_send(8'd1); host_send(8'd0); host_send("b"); host_recv(got);
    host_send(8'h40); host_send(8'd2); host_send(8'd0); host_send("c"); host_recv(got);
    do_shake_at(3, 200, 136,
      256'hcf0ea610eeff1a588290a53000faa79932becec0bd3cd0b33a7e5d397fed1ada,
      "SHAKE(abc,200)@136");

    $display("============================================================");
    if (errors==0)
      $display("  PASS -- SHA3-256 and SHAKE-256 verified over the UART path");
    else
      $display("  FAIL -- %0d error(s)", errors);
    $display("============================================================");
    $finish;
  end
  initial begin #900_000_000; $display("[TB] TIMEOUT state=%0d",dut.state); $finish; end
endmodule
