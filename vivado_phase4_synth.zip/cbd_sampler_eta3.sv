// =============================================================================
// cbd_sampler_eta3.sv -- Centered Binomial Distribution sampler, eta = 3
// FIPS 203 Algorithm 8 with eta = 3 (ML-KEM-512 secret sampling)
// -----------------------------------------------------------------------------
// 192 bytes SHAKE-256 output -> 256 coefficients in [-3,+3] (mod q).
// Per 3-byte group: d = sum of the 3 bits in each 3-bit field;
// 4 coefficients/group, each = (sum of 3 bits) - (sum of next 3 bits).
//
// READ MODEL: prf_rd_addr is a registered output and the PRF buffer read is
// itself synchronous, so a byte requested by driving prf_rd_addr in cycle N
// is valid on prf_rd_data in cycle N+2. The FSM below issues one address and
// waits two cycles before latching, for each of the 3 bytes -- explicit and
// robust rather than relying on a single settle cycle.
// =============================================================================
module cbd_sampler_eta3 (
  input  wire        clk,
  input  wire        rst_n,
  input  wire        start,
  input  wire [7:0]  prf_rd_data,
  output reg  [7:0]  prf_rd_addr,
  output reg  [7:0]  coeff_wr_addr,
  output reg  [15:0] coeff_wr_data,
  output reg         coeff_wr_en,
  output reg         busy,
  output reg         done
);
  import mlkem_pkg::*;

  localparam GROUPS = 64;

  reg [5:0]  group;
  reg [1:0]  sub;
  reg [1:0]  byte_idx;      // which of the 3 bytes we're fetching
  reg [1:0]  wait_cnt;      // read-latency counter
  reg [23:0] t_reg;
  reg [7:0]  bytes [0:2];

  localparam ST_IDLE  = 3'd0;
  localparam ST_ADDR  = 3'd1;   // drive address for byte_idx
  localparam ST_WAITB = 3'd2;   // wait read latency
  localparam ST_LATCH = 3'd3;   // capture byte
  localparam ST_CALC  = 3'd4;   // assemble t, compute d
  localparam ST_EMIT  = 3'd5;
  localparam ST_DONE  = 3'd6;

  reg [2:0] state;

  wire [7:0] base_addr = {2'd0, group} * 8'd3;

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= ST_IDLE; busy <= 1'b0; done <= 1'b0;
      group <= 6'd0; sub <= 2'd0; byte_idx <= 2'd0; wait_cnt <= 2'd0;
      coeff_wr_en <= 1'b0; prf_rd_addr <= 8'd0;
      t_reg <= 24'd0;
      coeff_wr_addr <= 8'd0; coeff_wr_data <= 16'd0;
      bytes[0] <= 8'd0; bytes[1] <= 8'd0; bytes[2] <= 8'd0;
    end else begin
      coeff_wr_en <= 1'b0;

      case (state)
        ST_IDLE: begin
          if (start) begin
            group <= 6'd0; sub <= 2'd0; byte_idx <= 2'd0;
            busy <= 1'b1; done <= 1'b0;
            state <= ST_ADDR;
          end
        end

        ST_ADDR: begin
          prf_rd_addr <= base_addr + {6'd0, byte_idx};
          wait_cnt <= 2'd0;
          state <= ST_WAITB;
        end

        // Wait for the 2-cycle read latency (addr reg + synchronous read).
        ST_WAITB: begin
          if (wait_cnt == 2'd1) state <= ST_LATCH;
          else wait_cnt <= wait_cnt + 2'd1;
        end

        ST_LATCH: begin
          bytes[byte_idx] <= prf_rd_data;
          if (byte_idx == 2'd2) begin
            byte_idx <= 2'd0;
            state <= ST_CALC;
          end else begin
            byte_idx <= byte_idx + 2'd1;
            state <= ST_ADDR;
          end
        end

        ST_CALC: begin
          t_reg <= {bytes[2], bytes[1], bytes[0]};
          sub   <= 2'd0;
          state <= ST_EMIT;    // d_reg computed from t_reg one cycle later
        end

        ST_EMIT: begin
          // Coefficient comes from coeff_now (combinational off t_reg), so
          // there is no stale-d hazard on the first coefficient of a group.
          coeff_wr_addr <= {group, sub};
          coeff_wr_data <= coeff_now;
          coeff_wr_en   <= 1'b1;

          if (sub == 2'd3) begin
            if (group == GROUPS - 1) state <= ST_DONE;
            else begin
              group <= group + 6'd1;
              state <= ST_ADDR;
            end
          end else sub <= sub + 2'd1;
        end

        ST_DONE: begin busy <= 1'b0; done <= 1'b1; state <= ST_IDLE; end
        default: state <= ST_IDLE;
      endcase
    end
  end

  // Combinational coefficient straight from t_reg (no dependence on d_reg
  // timing), eliminating the first-coefficient stale-d hazard entirely.
  wire [23:0] d_now = (t_reg & 24'h249249)
                    + ((t_reg >> 1) & 24'h249249)
                    + ((t_reg >> 2) & 24'h249249);
  wire [2:0] a_now = d_now[6*sub +: 3];
  wire [2:0] b_now = d_now[6*sub+3 +: 3];
  wire [15:0] coeff_now = (a_now >= b_now)
                            ? {13'd0, (a_now - b_now)}
                            : (16'd3329 - {13'd0, (b_now - a_now)});
endmodule : cbd_sampler_eta3
