// =============================================================================
// kpke_datapath.sv -- binds the verified units to kpke_engine's service
//                     interface over a real polynomial-slot memory map
// -----------------------------------------------------------------------------
// This is sub-phase 4F: the layer that turns "the control FSM issues the right
// calls in the right order" into "data actually flows correctly".
//
// Implemented here:
//   U_NTT    forward / inverse NTT, with copy-in and copy-out engines
//   U_MATVEC sum over k of mat[j] o vec[j], via matvec_mul
//   U_POLY   coefficient-wise add / subtract mod q
//   U_CODEC  ByteEncode_12 (two 12-bit coefficients -> three bytes)
//
// NOT implemented here (still stubbed at this level): U_HASH, U_XOF, U_PRF.
// Those need the Keccak cores plus their message buffers wired in, which is a
// separate integration step. Everything routed here is the ARITHMETIC core,
// and it is what the accompanying testbench drives end to end against the
// byte-exact golden model.
//
// WHY ntt_engine NEEDS COPY ENGINES
// ntt_engine keeps its coefficients in an INTERNAL memory (coeff_mem) rather
// than reading and writing an external polynomial store. So "NTT slot X into
// slot Y" is three phases: stream 256 coefficients from slot X into the
// engine, run the transform, then stream 256 results out into slot Y. That is
// 512 extra cycles per transform on top of the 5376 the transform itself
// takes -- about 10% overhead, and far cheaper than rewriting and re-verifying
// a hardware-validated engine to use external memory.
// =============================================================================
module kpke_datapath #(
  parameter integer K_PARAM = 2,
  parameter integer ADDR_W  = 13
)(
  input  wire        clk,
  input  wire        rst_n,

  // ---- service interface from kpke_engine ------------------------------
  input  wire [2:0]  unit_sel,
  input  wire [2:0]  unit_op,
  input  wire [7:0]  unit_a0,
  input  wire [7:0]  unit_a1,
  input  wire [7:0]  unit_a2,
  input  wire        unit_start,
  output reg         unit_done,

  // ---- polynomial slot memory ------------------------------------------
  output wire [ADDR_W-1:0] ps_a_addr,
  input  wire [15:0]       ps_a_data,
  output wire [ADDR_W-1:0] ps_b_addr,
  input  wire [15:0]       ps_b_data,
  output reg  [ADDR_W-1:0] ps_w_addr,
  output reg  [15:0]       ps_w_data,
  output reg               ps_w_en,

  // ---- byte output buffer (encoded keys) --------------------------------
  output reg  [10:0] byte_wr_addr,
  output reg  [7:0]  byte_wr_data,
  output reg         byte_wr_en,
  input  wire [10:0] byte_base,      // where this encode should start

  output reg  [4:0]  dbg_state
);
  import mlkem_pkg::*;

  localparam U_HASH   = 3'd0;
  localparam U_XOF    = 3'd1;
  localparam U_PRF    = 3'd2;
  localparam U_NTT    = 3'd3;
  localparam U_MATVEC = 3'd4;
  localparam U_POLY   = 3'd5;
  localparam U_CODEC  = 3'd6;

  localparam OP_NTT_FWD = 3'd0;
  localparam OP_NTT_INV = 3'd1;
  localparam OP_ADD     = 3'd0;
  localparam OP_SUB     = 3'd1;
  localparam OP_ENC12   = 3'd0;

  // Latched request
  reg [2:0] r_sel, r_op;
  reg [7:0] r_a0, r_a1, r_a2;

  // ---------------------------------------------------------------------------
  // NTT engine + its copy engines
  // ---------------------------------------------------------------------------
  reg         ntt_start, ntt_mode;
  reg  [7:0]  ntt_wr_addr;
  reg  [15:0] ntt_wr_data;
  reg         ntt_wr_en;
  reg  [7:0]  ntt_rd_addr;
  wire [15:0] ntt_rd_data;
  wire        ntt_busy, ntt_done;

  ntt_engine u_ntt (
    .clk(clk), .rst_n(rst_n), .start(ntt_start), .mode(ntt_mode),
    .done(ntt_done), .busy(ntt_busy),
    .wr_addr(ntt_wr_addr), .wr_data(ntt_wr_data), .wr_en(ntt_wr_en),
    .rd_addr(ntt_rd_addr), .rd_data(ntt_rd_data)
  );

  // ---------------------------------------------------------------------------
  // matvec_mul -- its 10-bit {jcol, coeff} addresses are rebased onto slots
  // ---------------------------------------------------------------------------
  reg         mv_start;
  wire [9:0]  mv_mat_addr, mv_vec_addr;
  reg  [7:0]  mv_acc_addr;
  wire [15:0] mv_acc_data;
  wire        mv_busy, mv_done;

  matvec_mul #(.K_PARAM(K_PARAM)) u_mv (
    .clk(clk), .rst_n(rst_n), .start(mv_start),
    .mat_rd_addr(mv_mat_addr), .mat_rd_data(ps_a_data),
    .vec_rd_addr(mv_vec_addr), .vec_rd_data(ps_b_data),
    .acc_rd_addr(mv_acc_addr), .acc_rd_data(mv_acc_data),
    .busy(mv_busy), .done(mv_done)
  );

  // Slot bases for the current matvec: row base for the matrix, vector base.
  reg [7:0] mat_base, vec_base;

  // ---------------------------------------------------------------------------
  // Modular add / subtract
  // ---------------------------------------------------------------------------
  wire [16:0] add_raw = ps_a_data + ps_b_data;
  wire [15:0] add_q   = (add_raw >= 17'd3329) ? (add_raw - 17'd3329) : add_raw[15:0];
  wire signed [16:0] sub_raw = $signed({1'b0, ps_a_data}) - $signed({1'b0, ps_b_data});
  wire [15:0] sub_q   = sub_raw[16] ? (sub_raw[15:0] + 16'd3329) : sub_raw[15:0];

  // ---------------------------------------------------------------------------
  // FSM
  // ---------------------------------------------------------------------------
  localparam ST_IDLE    = 5'd0;
  localparam ST_NTT_LD  = 5'd13;  // settle cycle before the first slot read
  localparam ST_NTT_IN  = 5'd1;   // stream slot -> engine
  localparam ST_NTT_GO  = 5'd14;  // wait for the engine to actually start
  localparam ST_NTT_RUN = 5'd2;
  localparam ST_NTT_OUT = 5'd3;   // stream engine -> slot
  localparam ST_MV_GO   = 5'd4;
  localparam ST_MV_ARM  = 5'd15;  // wait for matvec to actually start
  localparam ST_MV_WAIT = 5'd5;
  localparam ST_MV_COPY = 5'd6;   // matvec accumulator -> destination slot
  localparam ST_PL_RD   = 5'd7;   // poly add/sub: drive operand addresses
  localparam ST_PL_WR   = 5'd8;
  localparam ST_CD_A0   = 5'd9;   // encode: drive addr of even coefficient
  localparam ST_CD_W0   = 5'd10;  // settle
  localparam ST_CD_C0   = 5'd16;  // capture c0, drive addr of odd coefficient
  localparam ST_CD_W1   = 5'd17;  // settle
  localparam ST_CD_C1   = 5'd18;  // capture c1
  localparam ST_CD_B0   = 5'd19;  // emit byte 0
  localparam ST_CD_B1   = 5'd20;  // emit byte 1
  localparam ST_CD_B2   = 5'd21;  // emit byte 2
  localparam ST_STUB    = 5'd11;  // hash/XOF/PRF not routed at this level
  localparam ST_FIN     = 5'd12;

  reg [4:0] state;   // 5 bits: the state count outgrew 4 during 4F
  // Sequencer-driven read addresses. These are MUXED with matvec's addresses
  // below rather than being driven from two always blocks -- driving one reg
  // from two procedural blocks is DRC MDRV-1 (Multiple Driver Nets), which
  // already cost a synthesis run earlier in this project.
  reg [ADDR_W-1:0] seq_a_addr, seq_b_addr;
  wire mv_active = (state == ST_MV_GO) || (state == ST_MV_ARM)
                || (state == ST_MV_WAIT);
  assign ps_a_addr = mv_active
                   ? {(mat_base + {6'd0, mv_mat_addr[9:8]}), mv_mat_addr[7:0]}
                   : seq_a_addr;
  assign ps_b_addr = mv_active
                   ? {(vec_base + {6'd0, mv_vec_addr[9:8]}), mv_vec_addr[7:0]}
                   : seq_b_addr;

  reg [8:0] idx;        // 0..255 coefficient counter (9 bits for the 256 case)
  reg [1:0] bsub;       // which of the three encode bytes
  reg [15:0] c0_reg, c1_reg;
  reg [10:0] bcnt;      // byte offset within this encode

  always @(*) dbg_state = state;

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= ST_IDLE; unit_done <= 1'b0;
      r_sel <= 3'd0; r_op <= 3'd0; r_a0 <= 8'd0; r_a1 <= 8'd0; r_a2 <= 8'd0;
      ntt_start <= 1'b0; ntt_mode <= 1'b0; ntt_wr_en <= 1'b0;
      ntt_wr_addr <= 8'd0; ntt_wr_data <= 16'd0; ntt_rd_addr <= 8'd0;
      mv_start <= 1'b0; mv_acc_addr <= 8'd0;
      mat_base <= 8'd0; vec_base <= 8'd0;
      seq_a_addr <= {ADDR_W{1'b0}}; seq_b_addr <= {ADDR_W{1'b0}};
      ps_w_addr <= {ADDR_W{1'b0}}; ps_w_data <= 16'd0; ps_w_en <= 1'b0;
      byte_wr_addr <= 11'd0; byte_wr_data <= 8'd0; byte_wr_en <= 1'b0;
      idx <= 9'd0; bsub <= 2'd0; c0_reg <= 16'd0; c1_reg <= 16'd0;
      bcnt <= 11'd0;
    end else begin
      unit_done  <= 1'b0;
      ps_w_en    <= 1'b0;
      byte_wr_en <= 1'b0;
      ntt_wr_en  <= 1'b0;
      ntt_start  <= 1'b0;
      mv_start   <= 1'b0;

      case (state)
        ST_IDLE: begin
          if (unit_start) begin
            r_sel <= unit_sel; r_op <= unit_op;
            r_a0  <= unit_a0;  r_a1 <= unit_a1; r_a2 <= unit_a2;
            idx   <= 9'd0; bsub <= 2'd0;
            case (unit_sel)
              U_NTT: begin
                ntt_mode   <= (unit_op == OP_NTT_INV);
                seq_a_addr <= {unit_a1, 8'd0};      // source slot, coeff 0
                state      <= ST_NTT_LD;            // settle: slot read is registered
              end
              U_MATVEC: begin
                // a0 = row index; matrix base = SLOT_A + row*K, vector base = a1
                mat_base <= (unit_a0 * K_PARAM[7:0]);
                vec_base <= unit_a1;
                state    <= ST_MV_GO;
              end
              U_POLY: begin
                seq_a_addr <= {unit_a0, 8'd0};
                seq_b_addr <= {unit_a1, 8'd0};
                state     <= ST_PL_RD;
              end
              U_CODEC: begin
                if (unit_op == OP_ENC12) begin
                  seq_a_addr <= {unit_a1, 8'd0};
                  bcnt       <= 11'd0;
                  state      <= ST_CD_W0;   // settle: slot read is registered
                end else state <= ST_STUB;
              end
              default: state <= ST_STUB;   // U_HASH / U_XOF / U_PRF
            endcase
          end
        end

        // ---- NTT: stream source slot into the engine ---------------------
        // ps_a_addr was driven last cycle, so ps_a_data is valid now.
        // poly_slots registers its read, so the coefficient for the address
        // driven in ST_IDLE is not valid on ps_a_data until one cycle later.
        // Burn that cycle here and pre-drive the NEXT address.
        ST_NTT_LD: begin
          seq_a_addr <= {r_a1, 8'd1};
          state <= ST_NTT_IN;
        end

        ST_NTT_IN: begin
          ntt_wr_addr <= idx[7:0];
          ntt_wr_data <= ps_a_data;
          ntt_wr_en   <= 1'b1;
          if (idx == 9'd255) begin
            idx       <= 9'd0;
            ntt_start <= 1'b1;
            state     <= ST_NTT_GO;
          end else begin
            seq_a_addr <= {r_a1, idx[7:0] + 8'd2};   // one ahead of the capture
            idx       <= idx + 9'd1;
          end
        end

        // ntt_engine's `done` is LEVEL-HELD -- assign done = (state==ST_IDLE)
        // && was_last -- so it stays asserted after a completed transform.
        // Polling it directly made the SECOND NTT skip its transform entirely
        // and copy the untransformed input straight through. Gate on `busy`
        // instead: wait for the engine to start, then for it to finish.
        // (Third time this level-held-done pattern has bitten in this
        // project: sha3_512's testbench, poly_basemul, now ntt_engine.)
        ST_NTT_GO: if (ntt_busy) state <= ST_NTT_RUN;

        ST_NTT_RUN: if (!ntt_busy) begin
          ntt_rd_addr <= 8'd0;
          idx   <= 9'd0;
          state <= ST_NTT_OUT;
        end

        // ntt_rd_data is a CONTINUOUS assign off coeff_mem[rd_addr] -- it is
        // valid in the SAME cycle the address is stable, with no latency. An
        // earlier version offset the write by one here to "account for read
        // latency" that does not exist, which shifted the whole polynomial.
        ST_NTT_OUT: begin
          ps_w_addr <= {r_a2, ntt_rd_addr};
          ps_w_data <= ntt_rd_data;
          ps_w_en   <= 1'b1;
          if (idx == 9'd255) state <= ST_FIN;
          else begin
            ntt_rd_addr <= ntt_rd_addr + 8'd1;
            idx <= idx + 9'd1;
          end
        end

        // ---- matvec ------------------------------------------------------
        ST_MV_GO: begin
          mv_start <= 1'b1;
          state    <= ST_MV_ARM;
        end
        // Gate on busy rather than done, for the same reason as the NTT.
        ST_MV_ARM: if (mv_busy) state <= ST_MV_WAIT;
        ST_MV_WAIT: if (!mv_busy) begin
          mv_acc_addr <= 8'd0;
          idx   <= 9'd0;
          state <= ST_MV_COPY;
        end
        // matvec_mul's acc_rd_data is likewise a continuous assign -- no
        // latency, no offset.
        ST_MV_COPY: begin
          ps_w_addr <= {r_a2, mv_acc_addr};
          ps_w_data <= mv_acc_data;
          ps_w_en   <= 1'b1;
          if (idx == 9'd255) state <= ST_FIN;
          else begin
            mv_acc_addr <= mv_acc_addr + 8'd1;
            idx <= idx + 9'd1;
          end
        end

        // ---- poly add / sub ----------------------------------------------
        ST_PL_RD: state <= ST_PL_WR;    // one cycle for the slot read
        ST_PL_WR: begin
          ps_w_addr <= {r_a2, idx[7:0]};
          ps_w_data <= (r_op == OP_SUB) ? sub_q : add_q;
          ps_w_en   <= 1'b1;
          if (idx == 9'd255) state <= ST_FIN;
          else begin
            seq_a_addr <= {r_a0, idx[7:0] + 8'd1};
            seq_b_addr <= {r_a1, idx[7:0] + 8'd1};
            idx <= idx + 9'd1;
            state <= ST_PL_RD;
          end
        end

        // ---- ByteEncode_12: two 12-bit coefficients -> three bytes -------
        // Every slot read is followed by an explicit settle cycle; poly_slots
        // registers its output, so reading in the same cycle the address is
        // driven returns the PREVIOUS coefficient.
        ST_CD_A0: begin
          seq_a_addr <= {r_a1, idx[6:0], 1'b0};   // even coefficient 2*idx
          state <= ST_CD_W0;
        end
        ST_CD_W0: state <= ST_CD_C0;
        ST_CD_C0: begin
          c0_reg     <= ps_a_data;
          seq_a_addr <= {r_a1, idx[6:0], 1'b1};   // odd coefficient 2*idx+1
          state <= ST_CD_W1;
        end
        ST_CD_W1: state <= ST_CD_C1;
        ST_CD_C1: begin
          c1_reg <= ps_a_data;
          state  <= ST_CD_B0;
        end

        // b0 = c0[7:0]
        // b1 = c0[11:8] | (c1[3:0] << 4)
        // b2 = c1[11:4]
        ST_CD_B0: begin
          byte_wr_addr <= byte_base + bcnt;
          byte_wr_data <= c0_reg[7:0];
          byte_wr_en   <= 1'b1;
          bcnt  <= bcnt + 11'd1;
          state <= ST_CD_B1;
        end
        ST_CD_B1: begin
          byte_wr_addr <= byte_base + bcnt;
          byte_wr_data <= {c1_reg[3:0], c0_reg[11:8]};
          byte_wr_en   <= 1'b1;
          bcnt  <= bcnt + 11'd1;
          state <= ST_CD_B2;
        end
        ST_CD_B2: begin
          byte_wr_addr <= byte_base + bcnt;
          byte_wr_data <= c1_reg[11:4];
          byte_wr_en   <= 1'b1;
          bcnt <= bcnt + 11'd1;
          if (idx == 9'd127) state <= ST_FIN;
          else begin
            idx   <= idx + 9'd1;
            state <= ST_CD_A0;
          end
        end

        // Units not routed at this level complete immediately so the control
        // sequence still runs; the testbench preloads their results.
        ST_STUB: state <= ST_FIN;

        ST_FIN: begin
          unit_done <= 1'b1;
          state     <= ST_IDLE;
        end

        default: state <= ST_IDLE;
      endcase
    end
  end

endmodule : kpke_datapath
