// =============================================================================
// poly_slots.sv -- polynomial slot memory for the K-PKE datapath
// -----------------------------------------------------------------------------
// kpke_engine addresses polynomials by SLOT index (SLOT_A=0..3, SLOT_S=8..9,
// SLOT_SHAT=12..13, SLOT_T=16..17, SLOT_ACC=23, and so on). This module is the
// physical store behind those slots: NUM_SLOTS polynomials of 256 coefficients,
// flat-addressed as {slot, coeff}.
//
// Two read ports and one write port. That is exactly what the datapath needs
// at peak: matvec_mul reads a matrix column and a vector column simultaneously
// while writing its accumulator, and poly add/sub reads two operands and
// writes a third.
//
// ram_style is forced to block, for the reason established in Phase 2: at
// this size Vivado has been observed to leave arrays in flip-flops unless
// told otherwise, which is how 4096 registers appeared where a BRAM was
// expected. 24 x 256 x 16 = 96 Kbit, comfortably a handful of 36Kb tiles.
//
// Read latency is ONE cycle (registered output). Every consumer in this
// project accounts for that explicitly rather than assuming a combinational
// read -- getting it wrong has produced all-X digests and wrong coefficients
// four separate times here.
// =============================================================================
module poly_slots #(
  parameter integer NUM_SLOTS = 24,
  parameter integer ADDR_W    = 13     // ceil(log2(24*256)) = 13
)(
  input  wire              clk,

  // read port A
  input  wire [ADDR_W-1:0] a_addr,
  output reg  [15:0]       a_data,
  // read port B
  input  wire [ADDR_W-1:0] b_addr,
  output reg  [15:0]       b_data,
  // write port
  input  wire [ADDR_W-1:0] w_addr,
  input  wire [15:0]       w_data,
  input  wire              w_en
);

  (* ram_style = "block" *) reg [15:0] mem [0:NUM_SLOTS*256-1];

  always @(posedge clk) begin
    if (w_en) mem[w_addr] <= w_data;
    a_data <= mem[a_addr];
    b_data <= mem[b_addr];
  end

endmodule : poly_slots
