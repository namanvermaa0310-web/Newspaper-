# Phase 4 Synthesis -- What to Run, In Order

Phase 4 has never been through a synthesis tool. Every earlier phase had a
serious surprise on its first run (Phase 1 needed three rounds of pipelining;
Phase 2 ran 90 minutes and never finished because of a 136-port RAM). So do
NOT start with the full top -- go bottom-up, so that when something breaks you
know which module broke it.

Each stage is out-of-context synthesis only. No XDC, no implementation, no
bitstream. You are looking for three things at every stage:

  1. Does it finish in MINUTES?
  2. Any `[Synth 8-4767]` RAM warning? -- that is the canary from Phase 2
  3. Utilization: LUTs, FFs, DSPs, Block RAM

## One fix already applied

`poly_basemul.sv` previously loaded its 64-entry zeta table with
`$readmemh("golden_zeta64.hex")` inside an `initial` block. Vivado can infer a
ROM from that, but only if the hex is added as a design source and the relative
path resolves. That table is now an inline case statement, so no external file
is involved. Both affected testbenches were re-run and still pass.

`ntt_engine.sv` keeps its `initial for (...) coeff_mem[i] = 0;` -- that is a
BRAM power-on initialisation, it is synthesisable, and Phase 1 already built
with it.

## Project setup (once)

    File -> New Project -> RTL Project
    Part: xc7k325tffg900-2
    Add Sources:     all 19 .sv files in this folder
    Add Constraints: kpke_synth.xdc
    DO NOT add any tb_*.sv and DO NOT add any .hex

About the XDC: it is timing-only -- a 100 MHz create_clock, boundary false
paths, and two DRC severity downgrades so implementation can finish without
pin assignments. kpke_top has ~330 top-level port bits including a 256-bit
rho_out; it is an internal block, not a chip top, so there is nothing sensible
to pin. A board wrapper (IBUFDS + MMCM + reset sync + UART, like Phases 1-3
have) is what gets a pin XDC later.

For stages 1-7 you can leave the XDC out entirely if you prefer -- those are
synthesis-only and the clock constraint does not affect the utilisation
numbers. It is needed for stage 8.

VERIFIED: kpke_top elaborates cleanly from these 19 files alone, so nothing
external is required. If Vivado reports a missing module, a file was not added.

FILE ORDER: Vivado resolves the SystemVerilog packages (mlkem_pkg, keccak_pkg)
automatically in project mode. If you ever compile these by hand, the two
packages must come first -- several modules open with `import mlkem_pkg::*;`
and will throw a syntax error if the package has not been read yet.

Set the top per stage below (right-click the module -> Set as Top), then
Run Synthesis. Use Flow Navigator -> Open Synthesized Design -> Report
Utilization after each.

## Stage 1 -- basemul  (smallest, fastest sanity check)

    Top: basemul
    Sources needed: mlkem_pkg.sv, basemul.sv

Expect: seconds. A handful of DSP48s (the design has four 16x16-ish multiplies
in sequence, so 1-4 DSPs), a few hundred LUTs, no BRAM.
If DSP count is 0, the multipliers went into LUT fabric -- note it, it is not
fatal, but it will affect timing later.

## Stage 2 -- poly_basemul

    Top: poly_basemul
    Adds: poly_basemul.sv

Expect: seconds. Should be basemul plus a small FSM and the inlined 64-entry
ROM (a few LUTs, possibly a small distributed ROM). No BRAM.

## Stage 3 -- matvec_mul   *** first BRAM checkpoint ***

    Top: matvec_mul
    Adds: matvec_mul.sv

This module declares two 256x16 memories with
`(* ram_style = "block" *)` -- prod_mem and acc_mem.

CHECK: Block RAM Tile must be NONZERO (expect ~1 tile, since two 4Kbit
memories pack easily). If it reports 0 tiles and several thousand registers,
the same inference failure from Phase 2 has recurred and you should stop and
report it rather than continuing.

## Stage 4 -- poly_slots   *** the big memory ***

    Top: poly_slots
    Adds: poly_slots.sv

24 slots x 256 x 16 bits = 96 Kbit, one write port and TWO read ports.

CHECK: expect roughly 3-6 Block RAM tiles. Two read ports from one array may
cause Vivado to DUPLICATE the memory (one BRAM set per read port) -- that is
normal and acceptable, it just doubles the tile count. What is NOT acceptable
is 0 tiles with ~1500+ registers.

## Stage 5 -- kpke_datapath   *** first real timing signal ***

    Top: kpke_datapath
    Adds: ntt_engine.sv, twiddle_rom.sv, kpke_datapath.sv

This pulls in the NTT engine, which is the module that needed three rounds of
pipelining in Phase 1. It is already timing-closed at 100 MHz, so nothing new
should appear -- but this is the first time it is synthesised alongside the
copy engines and the matvec.

Expect: minutes. Note the utilization.

## Stage 6 -- kpke_seed_unit   *** the heaviest stage ***

    Top: kpke_seed_unit
    Adds: keccak_pkg.sv, keccak_round.sv, keccak_f1600.sv, sha3_512.sv,
          shake128.sv, shake256.sv, sample_ntt.sv, cbd_sampler.sv,
          cbd_sampler_eta3.sv, kpke_seed_unit.sv

THIS IS THE ONE MOST LIKELY TO GIVE TROUBLE. It instantiates THREE separate
Keccak sponges at once (SHA3-512, SHAKE-128, SHAKE-256), each with its own
1600-bit state and its own message buffer. That is three copies of the round
logic that Phase 2 found to be a wide, shallow combinational path.

Watch for:
  * `[Synth 8-4767]` on any msg_buf or out_mem
  * synthesis time creeping past ~10 minutes
  * very high LUT counts (three 1600-bit permutations is not small)

If this stage is clean, the rest will be.

An obvious optimisation if it is too large: the three sponges share the same
Keccak-f[1600] permutation and are never used simultaneously, so a single
shared core with muxed rate/domain parameters would cut the Keccak area to
roughly a third. Do not do this pre-emptively -- get the numbers first.

## Stage 7 -- kpke_top   *** the whole datapath ***

    Top: kpke_top
    Adds: kpke_top.sv (everything else already added)

Expect this to be the sum of stages 5 and 6 plus the arbitration mux.

Record: total LUT, FF, DSP, BRAM, and whether it finished in reasonable time.

## Stage 8 -- timing, once stage 7 is clean

Only now add a clock constraint. Create a small XDC with just:

    create_clock -period 10.000 -name clk [get_ports clk]

Run Implementation, then Report Timing Summary.

  * WNS positive -> record the number and stop; Phase 4 is synthesisable and
    meets timing at 100 MHz.
  * WNS negative -> record the number AND the worst path's startpoint and
    endpoint. Which module it lands in determines the fix, and guessing is
    what cost three rounds in Phase 1.

## What NOT to do yet

  * No board wrapper, no pin constraints, no bitstream. kpke_top has no UART
    and no top-level I/O worth pinning; it is an internal block. Bring-up
    plumbing comes after it synthesises and closes timing.
  * Do not synthesise kpke_engine or mlkem_fo_ctrl yet. kpke_engine's
    ByteEncode step still needs extending to loop over k polynomials, so it
    cannot correctly drive kpke_top; synthesising it now would only measure
    something that is about to change.

## Reporting back

For each stage, the useful line is:
    stage, top module, synthesis time, LUT / FF / DSP / BRAM, any 8-4767
and for stage 8, WNS plus the worst path endpoints.
