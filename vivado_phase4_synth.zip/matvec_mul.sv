// =============================================================================
// matvec_mul.sv -- one row of a matrix-vector product in the NTT domain
// -----------------------------------------------------------------------------
// Computes   acc = sum over j of ( mat[j] o vec[j] )   for j = 0 .. K_PARAM-1
// where 'o' is polynomial multiplication in the NTT domain (Algorithm 12,
// implemented by poly_basemul) and the sum is coefficient-wise mod q.
//
// This is the inner operation behind three separate FIPS 203 steps:
//   KeyGen  (Alg 13):  t_hat[i] = sum_j A_hat[i][j] o s_hat[j]   (+ e_hat[i])
//   Encrypt (Alg 14):  u_hat[i] = sum_j A_hat[j][i] o y_hat[j]   (transposed)
//                      v_hat    = sum_i t_hat[i]   o y_hat[i]
//   Decrypt (Alg 15):  w_hat    = sum_i s_hat[i]   o u_hat[i]
//
// The caller supplies mat[] and vec[] already laid out as K_PARAM consecutive
// 256-coefficient polynomials, addressed as {j, coeff}. The transpose needed
// by Encrypt is done by the CALLER's addressing, not here -- this module just
// walks j from 0 upward, which keeps it reusable for all four cases above.
//
// STRUCTURE: for each j, poly_basemul writes a full 256-coefficient product
// into an internal scratch memory, then a separate accumulate pass folds it
// into acc[]. Doing the add as its own pass rather than trying to accumulate
// inside poly_basemul keeps that module unchanged and independently verified.
// Cost is 256 extra cycles per column, which is small against the ~5000 the
// basemul pass itself takes.
//
// acc[] is zeroed on start, so the caller does not need to pre-clear it.
// =============================================================================
module matvec_mul #(
  parameter integer K_PARAM = 2      // ML-KEM-512
)(
  input  wire        clk,
  input  wire        rst_n,
  input  wire        start,

  // matrix row: K_PARAM polynomials, addressed as {j, coeff}
  output wire [9:0]  mat_rd_addr,
  input  wire [15:0] mat_rd_data,
  // vector: K_PARAM polynomials, addressed as {j, coeff}
  output wire [9:0]  vec_rd_addr,
  input  wire [15:0] vec_rd_data,

  // accumulated result, readable by the caller once done
  input  wire [7:0]  acc_rd_addr,
  output wire [15:0] acc_rd_data,

  output reg         busy,
  output reg         done
);
  import mlkem_pkg::*;

  // ---------------------------------------------------------------------------
  // Column index -- prefixed onto the caller's polynomial addresses
  // ---------------------------------------------------------------------------
  reg [1:0] jcol;

  // ---------------------------------------------------------------------------
  // poly_basemul instance: its 8-bit coefficient addresses are widened here
  // with the current column index.
  // ---------------------------------------------------------------------------
  reg         pbm_start;
  wire [7:0]  pbm_a_addr, pbm_b_addr, pbm_r_addr;
  wire [15:0] pbm_r_data;
  wire        pbm_r_en, pbm_busy, pbm_done;

  assign mat_rd_addr = {jcol, pbm_a_addr};
  assign vec_rd_addr = {jcol, pbm_b_addr};

  poly_basemul u_pbm (
    .clk(clk), .rst_n(rst_n), .start(pbm_start),
    .a_rd_addr(pbm_a_addr), .a_rd_data(mat_rd_data),
    .b_rd_addr(pbm_b_addr), .b_rd_data(vec_rd_data),
    .r_wr_addr(pbm_r_addr), .r_wr_data(pbm_r_data), .r_wr_en(pbm_r_en),
    .busy(pbm_busy), .done(pbm_done)
  );

  // ---------------------------------------------------------------------------
  // Scratch memory for one column product, and the accumulator.
  // Both are 256 x 16, single write port and single read port -> real BRAM.
  // ram_style is forced for the same reason as everywhere else in this
  // project: without it Vivado has been observed to leave arrays this size
  // in flip-flops.
  // ---------------------------------------------------------------------------
  (* ram_style = "block" *) reg [15:0] prod_mem [0:255];
  (* ram_style = "block" *) reg [15:0] acc_mem  [0:255];

  reg [7:0]  acc_idx;
  reg [7:0]  prod_raddr;
  reg [15:0] prod_q;
  reg [7:0]  accw_addr;
  reg [15:0] accw_data;
  reg        accw_en;
  reg [7:0]  accr_addr;
  reg [15:0] accr_q;

  always @(posedge clk) begin
    if (pbm_r_en) prod_mem[pbm_r_addr] <= pbm_r_data;
    prod_q <= prod_mem[prod_raddr];
  end

  always @(posedge clk) begin
    if (accw_en) acc_mem[accw_addr] <= accw_data;
    accr_q <= acc_mem[accr_addr];
  end

  assign acc_rd_data = acc_mem[acc_rd_addr];

  // Modular add: both operands are already < q, so one conditional subtract.
  wire [16:0] sum_raw = accr_q + prod_q;
  wire [15:0] sum_q   = (sum_raw >= 17'd3329) ? (sum_raw - 17'd3329) : sum_raw[15:0];

  // ---------------------------------------------------------------------------
  // FSM
  // ---------------------------------------------------------------------------
  localparam ST_IDLE   = 4'd0;
  localparam ST_ZERO   = 4'd1;   // clear acc[]
  localparam ST_PBM_GO = 4'd2;   // kick poly_basemul for column jcol
  localparam ST_PBM_W  = 4'd3;   // wait for it
  localparam ST_ADD_A  = 4'd4;   // drive read addresses for the add pass
  localparam ST_ADD_W  = 4'd5;   // read latency
  localparam ST_ADD_C  = 4'd6;   // commit acc[n] = acc[n] + prod[n]
  localparam ST_NEXT   = 4'd7;   // advance column
  localparam ST_DONE   = 4'd8;

  reg [3:0] state;

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= ST_IDLE; busy <= 1'b0; done <= 1'b0;
      jcol <= 2'd0; acc_idx <= 8'd0; pbm_start <= 1'b0;
      accw_en <= 1'b0; accw_addr <= 8'd0; accw_data <= 16'd0;
      accr_addr <= 8'd0; prod_raddr <= 8'd0;
    end else begin
      pbm_start <= 1'b0;
      accw_en   <= 1'b0;
      // `done` must be a ONE-CYCLE PULSE. Level-held done has now caused the
      // same class of bug four times in this project (sha3_512 testbench,
      // poly_basemul, ntt_engine, and here): a caller polls it, sees the
      // PREVIOUS operation's completion, and skips the current one entirely.
      done      <= 1'b0;

      case (state)
        ST_IDLE: begin
          if (start) begin
            jcol <= 2'd0; acc_idx <= 8'd0;
            busy <= 1'b1; done <= 1'b0;
            state <= ST_ZERO;
          end
        end

        // ---- zero the accumulator -----------------------------------------
        ST_ZERO: begin
          accw_addr <= acc_idx;
          accw_data <= 16'd0;
          accw_en   <= 1'b1;
          if (acc_idx == 8'd255) begin
            acc_idx <= 8'd0;
            state   <= ST_PBM_GO;
          end else acc_idx <= acc_idx + 8'd1;
        end

        // ---- multiply column jcol ------------------------------------------
        ST_PBM_GO: begin
          pbm_start <= 1'b1;
          state <= ST_PBM_W;
        end
        ST_PBM_W: if (pbm_done) begin
          acc_idx <= 8'd0;
          state <= ST_ADD_A;
        end

        // ---- accumulate: acc[n] += prod[n] --------------------------------
        ST_ADD_A: begin
          accr_addr  <= acc_idx;
          prod_raddr <= acc_idx;
          state <= ST_ADD_W;
        end
        ST_ADD_W: state <= ST_ADD_C;    // synchronous read latency
        ST_ADD_C: begin
          accw_addr <= acc_idx;
          accw_data <= sum_q;
          accw_en   <= 1'b1;
          if (acc_idx == 8'd255) state <= ST_NEXT;
          else begin
            acc_idx <= acc_idx + 8'd1;
            state <= ST_ADD_A;
          end
        end

        ST_NEXT: begin
          if (jcol == K_PARAM-1) state <= ST_DONE;
          else begin
            jcol  <= jcol + 2'd1;
            state <= ST_PBM_GO;
          end
        end

        ST_DONE: begin busy <= 1'b0; done <= 1'b1; state <= ST_IDLE; end
        default: state <= ST_IDLE;
      endcase
    end
  end
endmodule : matvec_mul
