// =============================================================================
// kpke_top.sv -- the complete K-PKE datapath
// -----------------------------------------------------------------------------
// Brings the two halves of sub-phase 4F together behind one service interface:
//
//   kpke_datapath   NTT (with copy engines), matvec_mul, modular add/sub,
//                   ByteEncode_12
//   kpke_seed_unit  SHA3-512 (G), SHAKE-128 + SampleNTT, SHAKE-256 + CBD
//
// Both write polynomial coefficients into the same slot memory, so the write
// port is ARBITRATED. The arbitration is trivially safe because the two halves
// are never active at once: kpke_engine issues one service call at a time and
// waits for unit_done before issuing the next. kpke_seed_unit raises `active`
// for exactly the window in which it owns the write port, and that flag is the
// select line here -- rather than, say, OR-ing the two write-enables, which
// would silently corrupt data if the no-overlap assumption were ever broken.
//
// unit_start is steered to whichever half implements the requested unit, and
// unit_done is the OR of the two (only one can be running).
// =============================================================================
module kpke_top #(
  parameter integer K_PARAM = 2,
  parameter integer ADDR_W  = 13
)(
  input  wire        clk,
  input  wire        rst_n,

  // ---- service interface (driven by kpke_engine or a testbench) ---------
  input  wire [2:0]  unit_sel,
  input  wire [2:0]  unit_op,
  input  wire [7:0]  unit_a0,
  input  wire [7:0]  unit_a1,
  input  wire [7:0]  unit_a2,
  input  wire        unit_start,
  output wire        unit_done,

  // ---- seed input -------------------------------------------------------
  input  wire [7:0]  d_rd_data,
  output wire [5:0]  d_rd_addr,

  // ---- encoded byte output ---------------------------------------------
  output wire [10:0] byte_wr_addr,
  output wire [7:0]  byte_wr_data,
  output wire        byte_wr_en,
  input  wire [10:0] byte_base,

  // ---- rho, needed by the caller to finish ek = encode(t_hat) || rho ----
  output wire [255:0] rho_out,

  output wire        sample_error
);

  localparam U_HASH = 3'd0;
  localparam U_XOF  = 3'd1;
  localparam U_PRF  = 3'd2;

  wire seed_call = (unit_sel == U_HASH) || (unit_sel == U_XOF)
                || (unit_sel == U_PRF);

  // ---------------------------------------------------------------------------
  // Slot memory
  // ---------------------------------------------------------------------------
  wire [ADDR_W-1:0] ps_a_addr, ps_b_addr;
  wire [15:0]       ps_a_data, ps_b_data;

  wire [ADDR_W-1:0] dp_w_addr, su_w_addr;
  wire [15:0]       dp_w_data, su_w_data;
  wire              dp_w_en,   su_w_en;
  wire              su_active;

  // Arbitration: the seed unit owns the write port while `active`.
  wire [ADDR_W-1:0] ps_w_addr = su_active ? su_w_addr : dp_w_addr;
  wire [15:0]       ps_w_data = su_active ? su_w_data : dp_w_data;
  wire              ps_w_en   = su_active ? su_w_en   : dp_w_en;

  poly_slots #(.NUM_SLOTS(24), .ADDR_W(ADDR_W)) u_slots (
    .clk(clk),
    .a_addr(ps_a_addr), .a_data(ps_a_data),
    .b_addr(ps_b_addr), .b_data(ps_b_data),
    .w_addr(ps_w_addr), .w_data(ps_w_data), .w_en(ps_w_en)
  );

  // ---------------------------------------------------------------------------
  // Arithmetic half
  // ---------------------------------------------------------------------------
  wire dp_done;
  kpke_datapath #(.K_PARAM(K_PARAM), .ADDR_W(ADDR_W)) u_dp (
    .clk(clk), .rst_n(rst_n),
    .unit_sel(unit_sel), .unit_op(unit_op),
    .unit_a0(unit_a0), .unit_a1(unit_a1), .unit_a2(unit_a2),
    .unit_start(unit_start & ~seed_call),
    .unit_done(dp_done),
    .ps_a_addr(ps_a_addr), .ps_a_data(ps_a_data),
    .ps_b_addr(ps_b_addr), .ps_b_data(ps_b_data),
    .ps_w_addr(dp_w_addr), .ps_w_data(dp_w_data), .ps_w_en(dp_w_en),
    .byte_wr_addr(byte_wr_addr), .byte_wr_data(byte_wr_data),
    .byte_wr_en(byte_wr_en), .byte_base(byte_base),
    .dbg_state()
  );

  // ---------------------------------------------------------------------------
  // Hashing / sampling half
  // ---------------------------------------------------------------------------
  wire su_done;
  kpke_seed_unit #(.K_PARAM(K_PARAM), .ADDR_W(ADDR_W)) u_su (
    .clk(clk), .rst_n(rst_n),
    .unit_sel(unit_sel), .unit_op(unit_op),
    .unit_a0(unit_a0), .unit_a1(unit_a1), .unit_a2(unit_a2),
    .unit_start(unit_start & seed_call),
    .unit_done(su_done), .active(su_active),
    .d_rd_data(d_rd_data), .d_rd_addr(d_rd_addr),
    .ps_w_addr(su_w_addr), .ps_w_data(su_w_data), .ps_w_en(su_w_en),
    .sample_error(sample_error),
    .dbg_state()
  );

  assign unit_done = dp_done | su_done;
  assign rho_out   = u_su.rho_reg;

endmodule : kpke_top
