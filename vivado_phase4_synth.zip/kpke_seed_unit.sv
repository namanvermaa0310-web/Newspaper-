// =============================================================================
// kpke_seed_unit.sv -- the hashing and sampling half of the K-PKE datapath
// -----------------------------------------------------------------------------
// Completes sub-phase 4F by routing the three service calls that
// kpke_datapath left stubbed:
//
//   U_HASH, op G : (rho, sigma) = G(d || k)              SHA3-512
//   U_XOF        : A_hat[i][j]  = SampleNTT(SHAKE128(rho || j || i))   Alg 7
//   U_PRF        : poly         = CBD_eta(SHAKE256(sigma || N))        Alg 8
//
// *** FIPS 203, NOT round-3 ***  The k byte appended to d in G is the
// parameter-set domain separator that FIPS 203 added; round-3's indcpa.c
// hashes d alone. Omitting it changes rho, sigma and every downstream byte.
//
// SIZING: MAX_MSG_BYTES on the hash cores must cover the largest input this
// design ever hashes. Here the inputs are small (33-34 bytes), but the FO
// layer above hashes ek (800 bytes) and z||c (800 bytes), so those
// instances must be parameterised to at least 800 -- the 512 default would
// silently truncate. Noted here because the same cores are reused there.
//
// DONE HANDLING: every sub-unit is waited on via BUSY (wait for it to rise,
// then to fall), never via `done`. Level-held `done` has caused the same
// skipped-operation bug four separate times in this project. Gating on busy
// is immune to it.
// =============================================================================
module kpke_seed_unit #(
  parameter integer K_PARAM = 2,
  parameter integer ADDR_W  = 13
)(
  input  wire        clk,
  input  wire        rst_n,

  // ---- service interface ------------------------------------------------
  input  wire [2:0]  unit_sel,
  input  wire [2:0]  unit_op,
  input  wire [7:0]  unit_a0,     // XOF: j    | PRF: N       | HASH: unused
  input  wire [7:0]  unit_a1,     // XOF: i    | PRF: eta     | HASH: unused
  input  wire [7:0]  unit_a2,     // destination slot
  input  wire        unit_start,
  output reg         unit_done,
  output reg         active,      // this unit owns the slot write port

  // ---- seed input (d) ---------------------------------------------------
  input  wire [7:0]  d_rd_data,
  output reg  [5:0]  d_rd_addr,

  // ---- polynomial slot write port --------------------------------------
  output reg  [ADDR_W-1:0] ps_w_addr,
  output reg  [15:0]       ps_w_data,
  output reg               ps_w_en,

  output reg         sample_error,
  output reg  [4:0]  dbg_state
);

  localparam U_HASH = 3'd0;
  localparam U_XOF  = 3'd1;
  localparam U_PRF  = 3'd2;

  // ---------------------------------------------------------------------------
  // rho / sigma, captured from G's 64-byte digest.
  // Digest byte i is hash_out[(63-i)*8 +: 8] -- byte 0 is the MSB, matching
  // the convention used by sha3_256/sha3_512 throughout this project.
  // ---------------------------------------------------------------------------
  reg [255:0] rho_reg, sigma_reg;
  function automatic [7:0] rho_byte  (input [5:0] i);
    rho_byte   = rho_reg[(31 - i)*8 +: 8];
  endfunction
  function automatic [7:0] sigma_byte(input [5:0] i);
    sigma_byte = sigma_reg[(31 - i)*8 +: 8];
  endfunction

  // ---------------------------------------------------------------------------
  // G = SHA3-512
  // ---------------------------------------------------------------------------
  reg         g_start; reg [9:0] g_len;
  reg  [8:0]  g_wr_addr; reg [7:0] g_wr_data; reg g_wr_en;
  wire        g_busy, g_done; wire [511:0] g_hash;

  sha3_512_mb #(.MAX_MSG_BYTES(64)) u_g (
    .clk(clk), .rst_n(rst_n), .start(g_start), .msg_len(g_len),
    .wr_addr(g_wr_addr), .wr_data(g_wr_data), .wr_en(g_wr_en),
    .busy(g_busy), .done(g_done), .hash_out(g_hash));

  // ---------------------------------------------------------------------------
  // XOF = SHAKE-128 (672 bytes, enough for SampleNTT's rejection loop)
  // ---------------------------------------------------------------------------
  reg         x_start; reg [9:0] x_mlen, x_olen;
  reg  [8:0]  x_wr_addr; reg [7:0] x_wr_data; reg x_wr_en;
  wire        x_busy, x_done;
  wire [9:0]  x_rd_addr; wire [7:0] x_rd_data;

  shake128 #(.MAX_MSG_BYTES(64), .MAX_OUT_BYTES(672)) u_x (
    .clk(clk), .rst_n(rst_n), .start(x_start), .msg_len(x_mlen),
    .wr_addr(x_wr_addr), .wr_data(x_wr_data), .wr_en(x_wr_en),
    .out_len(x_olen), .busy(x_busy), .done(x_done),
    .rd_addr(x_rd_addr), .rd_data(x_rd_data));

  // SampleNTT reads that stream directly.
  reg         sn_start;
  wire [7:0]  sn_wr_addr; wire [15:0] sn_wr_data; wire sn_wr_en;
  wire        sn_busy, sn_done, sn_err;

  sample_ntt u_sn (
    .clk(clk), .rst_n(rst_n), .start(sn_start), .stream_len(10'd672),
    .byte_rd_addr(x_rd_addr), .byte_rd_data(x_rd_data),
    .coeff_wr_addr(sn_wr_addr), .coeff_wr_data(sn_wr_data),
    .coeff_wr_en(sn_wr_en),
    .busy(sn_busy), .done(sn_done), .error(sn_err));

  // ---------------------------------------------------------------------------
  // PRF = SHAKE-256 (eta*64 bytes) feeding CBD eta=2 or eta=3
  // ---------------------------------------------------------------------------
  reg         p_start; reg [9:0] p_mlen, p_olen;
  reg  [8:0]  p_wr_addr; reg [7:0] p_wr_data; reg p_wr_en;
  wire        p_busy, p_done;
  wire [9:0]  p_rd_addr; wire [7:0] p_rd_data;

  reg  [9:0]  prf_addr_mux;
  assign p_rd_addr = prf_addr_mux;

  shake256 #(.MAX_MSG_BYTES(64), .MAX_OUT_BYTES(272)) u_p (
    .clk(clk), .rst_n(rst_n), .start(p_start), .msg_len(p_mlen),
    .wr_addr(p_wr_addr), .wr_data(p_wr_data), .wr_en(p_wr_en),
    .out_len(p_olen), .busy(p_busy), .done(p_done),
    .rd_addr(p_rd_addr), .rd_data(p_rd_data));

  reg         c2_start, c3_start;
  wire [6:0]  c2_rd_addr; wire [7:0] c2_wa; wire [15:0] c2_wd; wire c2_we;
  wire        c2_busy, c2_done;
  wire [7:0]  c3_rd_addr, c3_wa; wire [15:0] c3_wd; wire c3_we;
  wire        c3_busy, c3_done;

  cbd_sampler u_c2 (
    .clk(clk), .rst_n(rst_n), .start(c2_start),
    .byte_rd_addr(c2_rd_addr), .byte_rd_data(p_rd_data),
    .coeff_wr_addr(c2_wa), .coeff_wr_data(c2_wd), .coeff_wr_en(c2_we),
    .busy(c2_busy), .done(c2_done));

  cbd_sampler_eta3 u_c3 (
    .clk(clk), .rst_n(rst_n), .start(c3_start),
    .prf_rd_data(p_rd_data), .prf_rd_addr(c3_rd_addr),
    .coeff_wr_addr(c3_wa), .coeff_wr_data(c3_wd), .coeff_wr_en(c3_we),
    .busy(c3_busy), .done(c3_done));

  reg use_eta3;
  always @(*) begin
    prf_addr_mux = use_eta3 ? {2'd0, c3_rd_addr} : {3'd0, c2_rd_addr};
  end

  // ---------------------------------------------------------------------------
  // FSM
  // ---------------------------------------------------------------------------
  localparam S_IDLE    = 5'd0;
  // G(d || k)
  localparam S_G_W     = 5'd24;  // settle: d_rd_data is registered
  localparam S_G_LD    = 5'd1;   // stream d into the hash message buffer
  localparam S_G_K     = 5'd2;   // append the k byte
  localparam S_G_GO    = 5'd3;
  localparam S_G_ARM   = 5'd4;
  localparam S_G_WAIT  = 5'd5;
  localparam S_G_CAP   = 5'd6;   // capture rho and sigma
  // XOF -> SampleNTT
  localparam S_X_LD    = 5'd7;   // rho (32 bytes)
  localparam S_X_JI    = 5'd8;   // append j then i
  localparam S_X_GO    = 5'd9;
  localparam S_X_ARM   = 5'd10;
  localparam S_X_WAIT  = 5'd11;
  localparam S_SN_GO   = 5'd12;
  localparam S_SN_ARM  = 5'd13;
  localparam S_SN_WAIT = 5'd14;
  // PRF -> CBD
  localparam S_P_LD    = 5'd15;  // sigma (32 bytes)
  localparam S_P_N     = 5'd16;  // append N
  localparam S_P_GO    = 5'd17;
  localparam S_P_ARM   = 5'd18;
  localparam S_P_WAIT  = 5'd19;
  localparam S_C_GO    = 5'd20;
  localparam S_C_ARM   = 5'd21;
  localparam S_C_WAIT  = 5'd22;
  localparam S_FIN     = 5'd23;

  reg [4:0] state;
  reg [7:0] cnt;
  reg [7:0] r_a0, r_a1, r_a2;

  always @(*) dbg_state = state;

  // Slot writes are driven from whichever sampler is running.
  always @(*) begin
    ps_w_addr = {r_a2, (use_eta3 ? c3_wa : (sn_wr_en ? sn_wr_addr : c2_wa))};
    ps_w_data = sn_wr_en ? sn_wr_data : (use_eta3 ? c3_wd : c2_wd);
    ps_w_en   = sn_wr_en | c2_we | c3_we;
  end

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= S_IDLE; unit_done <= 1'b0; active <= 1'b0;
      cnt <= 8'd0; r_a0 <= 8'd0; r_a1 <= 8'd0; r_a2 <= 8'd0;
      rho_reg <= 256'd0; sigma_reg <= 256'd0; use_eta3 <= 1'b0;
      g_start <= 1'b0; g_len <= 10'd0; g_wr_en <= 1'b0;
      g_wr_addr <= 9'd0; g_wr_data <= 8'd0;
      x_start <= 1'b0; x_mlen <= 10'd0; x_olen <= 10'd0; x_wr_en <= 1'b0;
      x_wr_addr <= 9'd0; x_wr_data <= 8'd0; sn_start <= 1'b0;
      p_start <= 1'b0; p_mlen <= 10'd0; p_olen <= 10'd0; p_wr_en <= 1'b0;
      p_wr_addr <= 9'd0; p_wr_data <= 8'd0;
      c2_start <= 1'b0; c3_start <= 1'b0;
      d_rd_addr <= 6'd0; sample_error <= 1'b0;
    end else begin
      unit_done <= 1'b0;
      g_start <= 1'b0; g_wr_en <= 1'b0;
      x_start <= 1'b0; x_wr_en <= 1'b0; sn_start <= 1'b0;
      p_start <= 1'b0; p_wr_en <= 1'b0;
      c2_start <= 1'b0; c3_start <= 1'b0;

      case (state)
        S_IDLE: begin
          active <= 1'b0;
          if (unit_start) begin
            r_a0 <= unit_a0; r_a1 <= unit_a1; r_a2 <= unit_a2;
            cnt  <= 8'd0;
            case (unit_sel)
              U_HASH: begin d_rd_addr <= 6'd0; state <= S_G_W; end
              U_XOF:  begin active <= 1'b1; state <= S_X_LD; end
              U_PRF:  begin
                active   <= 1'b1;
                use_eta3 <= (unit_a1 == 8'd3);
                state    <= S_P_LD;
              end
              default: state <= S_IDLE;
            endcase
          end
        end

        // ---------------- G(d || k) ----------------------------------------
        // The seed memory registers its read, so the byte for the address
        // driven in S_IDLE is not on d_rd_data until one cycle later. Burn
        // that cycle here and keep the address one step ahead of the capture.
        S_G_W: begin
          d_rd_addr <= 6'd1;
          state <= S_G_LD;
        end

        S_G_LD: begin
          g_wr_addr <= {1'd0, cnt};
          g_wr_data <= d_rd_data;
          g_wr_en   <= 1'b1;
          if (cnt == 8'd31) begin state <= S_G_K; end
          else begin d_rd_addr <= cnt[5:0] + 6'd2; cnt <= cnt + 8'd1; end
        end
        S_G_K: begin
          g_wr_addr <= 9'd32;
          g_wr_data <= K_PARAM[7:0];     // FIPS 203 domain separator
          g_wr_en   <= 1'b1;
          state <= S_G_GO;
        end
        S_G_GO:   begin g_len <= 10'd33; g_start <= 1'b1; state <= S_G_ARM; end
        S_G_ARM:  if (g_busy) state <= S_G_WAIT;
        S_G_WAIT: if (!g_busy) state <= S_G_CAP;
        S_G_CAP: begin
          rho_reg   <= g_hash[511:256];   // digest bytes 0..31
          sigma_reg <= g_hash[255:0];     // digest bytes 32..63
          state <= S_FIN;
        end

        // ---------------- XOF(rho || j || i) -> SampleNTT -------------------
        S_X_LD: begin
          x_wr_addr <= {1'd0, cnt};
          x_wr_data <= rho_byte(cnt[5:0]);
          x_wr_en   <= 1'b1;
          if (cnt == 8'd31) begin cnt <= 8'd0; state <= S_X_JI; end
          else cnt <= cnt + 8'd1;
        end
        S_X_JI: begin
          if (cnt == 8'd0) begin
            x_wr_addr <= 9'd32; x_wr_data <= r_a0;   // j
            x_wr_en <= 1'b1; cnt <= 8'd1;
          end else begin
            x_wr_addr <= 9'd33; x_wr_data <= r_a1;   // i
            x_wr_en <= 1'b1; state <= S_X_GO;
          end
        end
        S_X_GO: begin
          x_mlen <= 10'd34; x_olen <= 10'd672;
          x_start <= 1'b1; state <= S_X_ARM;
        end
        S_X_ARM:  if (x_busy) state <= S_X_WAIT;
        S_X_WAIT: if (!x_busy) state <= S_SN_GO;
        S_SN_GO:  begin sn_start <= 1'b1; state <= S_SN_ARM; end
        S_SN_ARM: if (sn_busy) state <= S_SN_WAIT;
        S_SN_WAIT: if (!sn_busy) begin
          sample_error <= sn_err;
          state <= S_FIN;
        end

        // ---------------- PRF(sigma || N) -> CBD ---------------------------
        S_P_LD: begin
          p_wr_addr <= {1'd0, cnt};
          p_wr_data <= sigma_byte(cnt[5:0]);
          p_wr_en   <= 1'b1;
          if (cnt == 8'd31) state <= S_P_N;
          else cnt <= cnt + 8'd1;
        end
        S_P_N: begin
          p_wr_addr <= 9'd32; p_wr_data <= r_a0;    // nonce N
          p_wr_en <= 1'b1; state <= S_P_GO;
        end
        S_P_GO: begin
          p_mlen <= 10'd33;
          p_olen <= use_eta3 ? 10'd192 : 10'd128;   // eta*64
          p_start <= 1'b1; state <= S_P_ARM;
        end
        S_P_ARM:  if (p_busy) state <= S_P_WAIT;
        S_P_WAIT: if (!p_busy) state <= S_C_GO;
        S_C_GO: begin
          if (use_eta3) c3_start <= 1'b1; else c2_start <= 1'b1;
          state <= S_C_ARM;
        end
        S_C_ARM:  if (use_eta3 ? c3_busy : c2_busy) state <= S_C_WAIT;
        S_C_WAIT: if (!(use_eta3 ? c3_busy : c2_busy)) state <= S_FIN;

        S_FIN: begin
          unit_done <= 1'b1;
          active    <= 1'b0;
          state     <= S_IDLE;
        end

        default: state <= S_IDLE;
      endcase
    end
  end
endmodule : kpke_seed_unit
