// =============================================================================
// basemul.sv -- Basecase multiplier for ML-KEM (FIPS 203 Algorithm 11)
// -----------------------------------------------------------------------------
// Multiplies two degree-1 polynomials in Z_q[X]/(X^2 - zeta):
//
//   Given a = a0 + a1*X  and  b = b0 + b1*X  in Z_q[X]/(X^2 - zeta):
//   r = a * b mod (X^2 - zeta)
//     = (a0*b0 + a1*b1*zeta) + (a0*b1 + a1*b0)*X
//
// This is FIPS 203 Algorithm 11 (BaseCaseMultiply). 64 of these (with
// alternating +/- zeta signs from zetas[64..127]) make up one full
// polynomial multiplication in NTT domain (Algorithm 12).
//
// ARITHMETIC CONVENTION: plain Barrett reduction, matching Phases 1-3.
// The round-3 C reference uses Montgomery form (stores zeta*2^16 mod q,
// multiplies via montgomery_reduce). We stay in plain form deliberately:
//   - consistent with the NTT engine already hardware-validated
//   - FIPS 203 spec is written in plain arithmetic
//   - Montgomery is an optimization, not a correctness requirement
//   - mixing representations mid-project is where subtle bugs hide
//
// PIPELINING: same "one multiplier per stage" discipline as ntt_engine.
// basemul needs 4 multiplies (a1*b1, *zeta, a0*b0, a0*b1, a1*b0) plus
// Barrett reductions. Each multiply+reduce uses 3 pipeline stages
// (MUL, BARRETT_EST, BARRETT_CORR), and we need 4 such sequences plus
// some adds. Total: ~20 cycles per basemul pair.
//
// For a full poly_basemul (64 pairs), this FSM is called 64 times by
// the orchestrator, reading coefficient pairs from the polynomial
// memories and writing results back.
// =============================================================================
module basemul (
  input  wire        clk,
  input  wire        rst_n,
  input  wire        start,        // pulse to begin one basemul(a[0:1], b[0:1], zeta)
  input  wire [15:0] a0, a1,       // first polynomial:  a0 + a1*X
  input  wire [15:0] b0, b1,       // second polynomial: b0 + b1*X
  input  wire [15:0] zeta,         // reduction polynomial root
  output reg  [15:0] r0, r1,       // result: r0 + r1*X
  output reg         done,
  output wire        busy
);
  import mlkem_pkg::*;

  // =========================================================================
  // Barrett reduction helper: reduce a product mod q.
  // Reused exactly as in ntt_engine: x -> x*20159+2^25, >>26 -> *3329,
  // subtract, conditional fixup.
  // Split across 3 pipeline stages (MUL, EST, CORR) so no stage holds
  // more than one multiplier.
  // =========================================================================

  // Pipeline registers
  reg [31:0] mul_result;       // raw a*b product
  reg [23:0] prod_hold;        // low 24 bits carried forward
  reg [12:0] tval;             // Barrett quotient estimate
  reg [15:0] reduced;          // final reduced value

  // Barrett combinational logic (active in the appropriate state)
  wire [38:0] bar_est  = (mul_result[23:0] * 24'd20159) + 26'd33554432;
  wire [24:0] bar_diff = {1'b0, prod_hold} - (tval * 25'd3329);
  wire [15:0] bar_out  = bar_diff[24]          ? (bar_diff[15:0] + 16'd3329) :
                         (bar_diff >= 25'd3329) ? (bar_diff[15:0] - 16'd3329) :
                         bar_diff[15:0];

  // =========================================================================
  // FSM: compute r0 = (a0*b0 + a1*b1*zeta) mod q
  //              r1 = (a0*b1 + a1*b0)       mod q
  //
  // Sequence (each "reduce" = MUL+EST+CORR = 3 cycles):
  //   1. reduce(a1 * b1)         -> t1
  //   2. reduce(t1 * zeta)       -> t2
  //   3. reduce(a0 * b0)         -> t3
  //   4. r0 = (t2 + t3) mod q
  //   5. reduce(a0 * b1)         -> t4
  //   6. reduce(a1 * b0)         -> t5
  //   7. r1 = (t4 + t5) mod q
  //   Total: 4 reduce sequences (12 cycles) + 2 add cycles = ~14 cycles
  // =========================================================================
  localparam S_IDLE  = 5'd0;
  // a1*b1
  localparam S_M1    = 5'd1;   // MUL: a1*b1
  localparam S_E1    = 5'd2;   // EST
  localparam S_C1    = 5'd3;   // CORR -> t1
  // t1*zeta
  localparam S_M2    = 5'd4;
  localparam S_E2    = 5'd5;
  localparam S_C2    = 5'd6;   // -> t2
  // a0*b0
  localparam S_M3    = 5'd7;
  localparam S_E3    = 5'd8;
  localparam S_C3    = 5'd9;   // -> t3
  // r0 = (t2+t3) mod q
  localparam S_ADD0  = 5'd10;
  // a0*b1
  localparam S_M4    = 5'd11;
  localparam S_E4    = 5'd12;
  localparam S_C4    = 5'd13;  // -> t4
  // a1*b0
  localparam S_M5    = 5'd14;
  localparam S_E5    = 5'd15;
  localparam S_C5    = 5'd16;  // -> t5
  // r1 = (t4+t5) mod q
  localparam S_ADD1  = 5'd17;
  localparam S_DONE  = 5'd18;

  reg [4:0] state;
  reg [15:0] t2_reg, t3_reg, t4_reg;   // intermediate results
  reg [15:0] a0_r, a1_r, b0_r, b1_r, zeta_r;  // latched inputs

  assign busy = (state != S_IDLE);

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= S_IDLE; done <= 1'b0;
      r0 <= 16'd0; r1 <= 16'd0;
      mul_result <= 32'd0; prod_hold <= 24'd0; tval <= 13'd0; reduced <= 16'd0;
      t2_reg <= 16'd0; t3_reg <= 16'd0; t4_reg <= 16'd0;
      a0_r <= 16'd0; a1_r <= 16'd0; b0_r <= 16'd0; b1_r <= 16'd0; zeta_r <= 16'd0;
    end else begin
      done <= 1'b0;

      case (state)
        S_IDLE: begin
          if (start) begin
            a0_r <= a0; a1_r <= a1; b0_r <= b0; b1_r <= b1; zeta_r <= zeta;
            state <= S_M1;
          end
        end

        // ---- a1 * b1 -> reduce -> t1 (held in reduced) ------------------
        S_M1: begin mul_result <= a1_r * b1_r;                    state <= S_E1; end
        S_E1: begin tval <= bar_est[38:26]; prod_hold <= mul_result[23:0]; state <= S_C1; end
        S_C1: begin reduced <= bar_out;                           state <= S_M2; end

        // ---- t1 * zeta -> reduce -> t2 ----------------------------------
        S_M2: begin mul_result <= reduced * zeta_r;               state <= S_E2; end
        S_E2: begin tval <= bar_est[38:26]; prod_hold <= mul_result[23:0]; state <= S_C2; end
        S_C2: begin t2_reg <= bar_out;                            state <= S_M3; end

        // ---- a0 * b0 -> reduce -> t3 ------------------------------------
        S_M3: begin mul_result <= a0_r * b0_r;                    state <= S_E3; end
        S_E3: begin tval <= bar_est[38:26]; prod_hold <= mul_result[23:0]; state <= S_C3; end
        S_C3: begin t3_reg <= bar_out;                            state <= S_ADD0; end

        // ---- r0 = (t2 + t3) mod q ---------------------------------------
        S_ADD0: begin
          r0 <= ((t2_reg + t3_reg) >= 16'd3329) ? (t2_reg + t3_reg - 16'd3329)
                                                 : (t2_reg + t3_reg);
          state <= S_M4;
        end

        // ---- a0 * b1 -> reduce -> t4 ------------------------------------
        S_M4: begin mul_result <= a0_r * b1_r;                    state <= S_E4; end
        S_E4: begin tval <= bar_est[38:26]; prod_hold <= mul_result[23:0]; state <= S_C4; end
        S_C4: begin t4_reg <= bar_out;                            state <= S_M5; end

        // ---- a1 * b0 -> reduce -> t5 (held in reduced) ------------------
        S_M5: begin mul_result <= a1_r * b0_r;                    state <= S_E5; end
        S_E5: begin tval <= bar_est[38:26]; prod_hold <= mul_result[23:0]; state <= S_C5; end
        S_C5: begin reduced <= bar_out;                           state <= S_ADD1; end

        // ---- r1 = (t4 + t5) mod q ---------------------------------------
        S_ADD1: begin
          r1 <= ((t4_reg + reduced) >= 16'd3329) ? (t4_reg + reduced - 16'd3329)
                                                  : (t4_reg + reduced);
          state <= S_DONE;
        end

        S_DONE: begin done <= 1'b1; state <= S_IDLE; end

        default: state <= S_IDLE;
      endcase
    end
  end
endmodule : basemul
