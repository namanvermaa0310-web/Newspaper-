// SHAKE-128: rate 168 bytes (capacity 256), domain byte 0x1F.
// Re-forked from the FIXED shake256.sv -- the original fork inherited the
// 168-parallel-read msg_buf pattern that Vivado could not map to RAM.
// Only RATE_BYTES, the block_reg width (1344 bits) and the absorb zero-pad
// width (256 bits) differ. Needed by ML-KEM for matrix expansion:
//   A_hat[i][j] = SampleNTT(XOF(rho||j||i)), XOF = SHAKE-128.
// =============================================================================
module shake128 #(
  parameter MAX_MSG_BYTES = 512,
  parameter MAX_OUT_BYTES = 672
) (
  input  wire        clk,
  input  wire        rst_n,
  input  wire        start,
  input  wire [9:0]  msg_len,
  // 11 bits, not 9: with MAX_MSG_BYTES > 512 a 9-bit address WRAPS and
  // silently overwrites the start of the message. The FO layer hashes ek
  // (800 B) and z||c (800 B), which is exactly that case.
  input  wire [10:0] wr_addr,
  input  wire [7:0]  wr_data,
  input  wire        wr_en,
  input  wire [9:0]  out_len,      // desired output length, <= MAX_OUT_BYTES
  output reg         busy,
  output reg         done,
  input  wire [9:0]  rd_addr,
  output wire [7:0]  rd_data
);
  localparam RATE_BYTES = 168;

  // ---------------------------------------------------------------------------
  // Message buffer: one write port, one read port -> infers as RAM
  // ---------------------------------------------------------------------------
  (* ram_style = "block" *) reg [7:0] msg_buf [0:MAX_MSG_BYTES-1];
  reg [10:0] mb_raddr;
  reg [7:0] mb_q;
  always @(posedge clk) begin
    if (wr_en) msg_buf[wr_addr] <= wr_data;
    mb_q <= msg_buf[mb_raddr];
  end

  // ---------------------------------------------------------------------------
  // Output memory: one write port (squeeze), one read port (host) -> RAM
  // ---------------------------------------------------------------------------
  (* ram_style = "block" *) reg [7:0] out_mem [0:MAX_OUT_BYTES-1];
  reg [9:0] om_waddr;
  reg [7:0] om_wdata;
  reg       om_wen;
  always @(posedge clk) begin
    if (om_wen) out_mem[om_waddr] <= om_wdata;
  end
  assign rd_data = out_mem[rd_addr];

  reg  [9:0] msg_len_reg;
  reg  [9:0] out_len_reg;
  reg  [7:0] blk_idx;
  wire [9:0] total_padded_len = msg_len_reg + 10'd1 + 10'((RATE_BYTES-1));
  wire [7:0] num_blocks = total_padded_len / RATE_BYTES;

  reg [1599:0] sponge_state;

  // ---------------------------------------------------------------------------
  // Absorb: sequentially-loaded rate block (packed vector -> flops)
  // Domain-separation byte is 0x1F for SHAKE (0x06 for SHA3).
  // ---------------------------------------------------------------------------
  reg [1343:0] block_reg;
  reg [7:0]    ld_idx;
  wire [11:0]  gidx = blk_idx * RATE_BYTES + ld_idx;
  wire         is_last_block = (blk_idx == num_blocks - 8'd1);

  wire [7:0] raw_byte = (gidx <  {1'b0, msg_len_reg}) ? mb_q  :
                        (gidx == {1'b0, msg_len_reg}) ? 8'h1F : 8'h00;
  wire [7:0] padded_byte =
        (is_last_block && (ld_idx == RATE_BYTES-1)) ? (raw_byte | 8'h80)
                                                    : raw_byte;

  wire [1599:0] xored_state = sponge_state ^ {256'd0, block_reg};

  // ---------------------------------------------------------------------------
  // Squeeze: one byte per cycle out of sponge_state, LE within each lane
  // ---------------------------------------------------------------------------
  reg [7:0] sq_idx;                    // 0 .. RATE_BYTES-1 within this block
  wire [63:0] sq_lane = sponge_state[64*(sq_idx/8) +: 64];
  wire [7:0]  sq_byte = sq_lane[8*(sq_idx%8) +: 8];

  reg          f_start;
  reg  [1599:0] f_state_in;
  wire [1599:0] f_state_out;
  wire         f_busy, f_done;

  keccak_f1600 u_f1600 (
    .clk(clk), .rst_n(rst_n), .start(f_start),
    .state_in(f_state_in), .state_out(f_state_out),
    .busy(f_busy), .done(f_done)
  );

  localparam ST_IDLE  = 4'd0,  ST_LD_A   = 4'd1, ST_LD_W  = 4'd10,
             ST_LD_B  = 4'd2,
             ST_XOR   = 4'd3,  ST_KICK   = 4'd4, ST_RUN   = 4'd5,
             ST_SQ    = 4'd6,  ST_SQKICK = 4'd7, ST_SQRUN = 4'd8,
             ST_DONE  = 4'd9;
  reg [3:0] state;

  reg [9:0] out_written;   // bytes committed to out_mem so far

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= ST_IDLE; busy <= 1'b0; done <= 1'b0; f_start <= 1'b0;
      f_state_in <= 1600'd0; sponge_state <= 1600'd0;
      blk_idx <= 8'd0; msg_len_reg <= 10'd0; out_len_reg <= 10'd0;
      out_written <= 10'd0; block_reg <= 1088'd0; ld_idx <= 8'd0;
      sq_idx <= 8'd0; mb_raddr <= 9'd0;
      om_waddr <= 10'd0; om_wdata <= 8'd0; om_wen <= 1'b0;
    end else begin
      f_start <= 1'b0;
      om_wen  <= 1'b0;

      case (state)
        ST_IDLE, ST_DONE: begin
          if (state == ST_DONE) done <= 1'b1;
          if (start) begin
            msg_len_reg  <= msg_len;
            out_len_reg  <= out_len;
            blk_idx      <= 8'd0;
            sponge_state <= 1600'd0;
            block_reg    <= 1088'd0;
            ld_idx       <= 8'd0;
            sq_idx       <= 8'd0;
            out_written  <= 10'd0;
            busy         <= 1'b1;
            done         <= 1'b0;
            state        <= ST_LD_A;
          end
        end

        // ---- absorb: sequential block load -------------------------------
        ST_LD_A: begin
          mb_raddr <= gidx[10:0];
          state    <= ST_LD_W;
        end

        // mb_raddr only takes effect at the END of ST_LD_A, so the RAM read
        // it triggers does not land in mb_q until the end of THIS state.
        // Capturing in ST_LD_A+1 would latch the PREVIOUS byte -- an
        // off-by-one that showed up immediately as an all-X digest.
        ST_LD_W: state <= ST_LD_B;
        ST_LD_B: begin
          block_reg[8*ld_idx +: 8] <= padded_byte;
          if (ld_idx == RATE_BYTES-1) begin
            ld_idx <= 8'd0;
            state  <= ST_XOR;
          end else begin
            ld_idx <= ld_idx + 8'd1;
            state  <= ST_LD_A;
          end
        end

        ST_XOR: begin
          f_state_in <= xored_state;
          f_start    <= 1'b1;
          state      <= ST_KICK;
        end
        ST_KICK: state <= ST_RUN;
        ST_RUN: begin
          if (f_done) begin
            sponge_state <= f_state_out;
            if (blk_idx == num_blocks - 8'd1) begin
              sq_idx <= 8'd0;
              state  <= ST_SQ;      // absorb done, start squeezing
            end else begin
              blk_idx <= blk_idx + 8'd1;
              state   <= ST_LD_A;
            end
          end
        end

        // ---- squeeze: one byte per cycle ----------------------------------
        ST_SQ: begin
          if ((out_written + {2'd0, sq_idx}) < out_len_reg) begin
            om_waddr <= out_written + {2'd0, sq_idx};
            om_wdata <= sq_byte;
            om_wen   <= 1'b1;
          end

          if (((out_written + {2'd0, sq_idx}) + 10'd1 >= out_len_reg)) begin
            // all requested output produced
            out_written <= out_len_reg;
            busy  <= 1'b0;
            done  <= 1'b1;
            state <= ST_DONE;
          end else if (sq_idx == RATE_BYTES-1) begin
            // this rate block is exhausted but more output is needed:
            // permute again, then keep squeezing
            out_written <= out_written + RATE_BYTES[9:0];
            sq_idx      <= 8'd0;
            f_state_in  <= sponge_state;
            f_start     <= 1'b1;
            state       <= ST_SQKICK;
          end else begin
            sq_idx <= sq_idx + 8'd1;
          end
        end

        ST_SQKICK: state <= ST_SQRUN;
        ST_SQRUN: begin
          if (f_done) begin
            sponge_state <= f_state_out;
            sq_idx <= 8'd0;
            state  <= ST_SQ;
          end
        end

        default: state <= ST_IDLE;
      endcase
    end
  end
endmodule : shake128
