// =============================================================================
// kpke_system.sv -- kpke_engine driving kpke_top
// -----------------------------------------------------------------------------
// Until now the two halves of K-PKE had never been connected: kpke_engine was
// verified against behavioural stubs (call order), and kpke_top was verified
// against a testbench that issued the service calls by hand (data). This module
// closes that gap -- the FSM now drives the real datapath.
//
// The only wiring of note is byte_base. kpke_engine owns it because only the
// sequencer knows which polynomial of which key is currently being encoded;
// kpke_datapath just writes bytes starting wherever it is told.
//
// Interface to the caller is a single operation request:
//     op = 0 KeyGen, 1 Encrypt, 2 Decrypt
// plus the seed port and the encoded-byte output. That is exactly the shape
// mlkem_fo_ctrl expects from a K-PKE service, so the FO layer drops on top of
// this without further adaptation.
// =============================================================================
module kpke_system #(
  parameter integer K_PARAM = 2,
  parameter integer ADDR_W  = 13,
  parameter [12:0]  EK_BASE_P = 13'd0
)(
  input  wire        clk,
  input  wire        rst_n,

  input  wire [1:0]  op,          // 0 = KeyGen, 1 = Encrypt, 2 = Decrypt
  input  wire        start,
  output wire        busy,
  output wire        done,

  // seed / private input bytes
  input  wire [7:0]  d_rd_data,
  output wire [5:0]  d_rd_addr,

  // encoded output bytes (ek at 0, dk at 1024)
  output wire [12:0] byte_wr_addr,
  output wire [7:0]  byte_wr_data,
  output wire        byte_wr_en,
  // byte-buffer read port: ByteDecode, Decompress and add-message all need
  // to read back bytes the caller supplied (ek, ciphertext, message).
  output wire [12:0] byte_rd_addr,
  input  wire [7:0]  byte_rd_data,

  output wire [255:0] rho_out,
  output wire         sample_error,
  output wire [5:0]   dbg_engine_state
);

  wire [2:0]  unit_sel, unit_op;
  wire [7:0]  unit_a0, unit_a1, unit_a2;
  wire        unit_start, unit_done;
  wire [12:0] byte_base;

  kpke_engine #(
    .K_PARAM(K_PARAM), .ETA1(3), .ETA2(2), .DU(10), .DV(4), .EK_BASE_P(EK_BASE_P)
  ) u_engine (
    .clk(clk), .rst_n(rst_n),
    .op(op), .start(start), .busy(busy), .done(done),
    .unit_sel(unit_sel), .unit_op(unit_op),
    .unit_a0(unit_a0), .unit_a1(unit_a1), .unit_a2(unit_a2),
    .unit_start(unit_start), .unit_done(unit_done),
    .byte_base(byte_base),
    .dbg_state(dbg_engine_state)
  );

  kpke_top #(
    .K_PARAM(K_PARAM), .ADDR_W(ADDR_W)
  ) u_kpke (
    .clk(clk), .rst_n(rst_n),
    .unit_sel(unit_sel), .unit_op(unit_op),
    .unit_a0(unit_a0), .unit_a1(unit_a1), .unit_a2(unit_a2),
    .unit_start(unit_start), .unit_done(unit_done),
    .d_rd_data(d_rd_data), .d_rd_addr(d_rd_addr),
    .byte_wr_addr(byte_wr_addr), .byte_wr_data(byte_wr_data),
    .byte_wr_en(byte_wr_en),
    .byte_rd_addr(byte_rd_addr), .byte_rd_data(byte_rd_data),
    .byte_base(byte_base),
    .rho_out(rho_out), .sample_error(sample_error)
  );

endmodule : kpke_system
