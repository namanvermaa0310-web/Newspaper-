# ML-KEM-512 on the KC705 -- bring-up and demonstration

31 files: 28 RTL (the verified KEM plus the UART bridge and board wrapper),
one pin XDC, and the host driver.

## What is new versus the simulation package

  mlkem_uart_core.sv   Board-independent UART command bridge. Owns the 8 KB
                       byte buffer (two read ports -- verify_cmov compares
                       two ciphertexts in the same cycle) and the seed
                       memory. Fully simulatable.
  kc705_mlkem_top.sv   The ONLY board-specific file: IBUFDS + MMCM + reset
                       synchroniser. Same scheme as the Phase 1-3 wrappers,
                       which are already hardware-proven on this board.
  kc705_mlkem.xdc      Six real pins. THIS one produces a bitstream.
  host_mlkem.py        PC driver with three modes (below).

## FIXES IN THIS REVISION -- REBUILD THE BITSTREAM

### 2. kpke_seed_unit: write mux keyed off a stale mode flag

The seed unit's polynomial write mux selected between SampleNTT and the two
CBD samplers using `use_eta3` -- a flag that is ONLY assigned when a PRF call
is issued. During an XOF call it therefore held whatever the last PRF left
behind. KeyGen ends with CBD eta=3 sampling, so `use_eta3` was left SET, and
the NEXT KeyGen's SampleNTT writes were muxed to the CBD3 address and data.
A_hat was never regenerated: the first KeyGen after a reset was correct and
every one after it was wrong.

This is what the board was showing -- tcId 1 OK, tcId 2..4 wrong from byte 0,
then a hang. Simulation never caught it because no testbench had run two
KeyGens back to back.

The mux is now driven by the sub-units' actual write-enables, which is immune
to any stale mode flag:

    ps_w_en   = sn_wr_en | c2_we | c3_we;
    ps_w_addr = {r_a2, sn_wr_en ? sn_wr_addr : (c3_we ? c3_wa : c2_wa)};
    ps_w_data = sn_wr_en ? sn_wr_data : (c3_we ? c3_wd : c2_wd);

Verified with tb_uart_race2.sv, which drives TWO back-to-back KeyGens through
the real UART protocol:

    op1 ek = 3995815e...   (matches the known-good vector)
    op2 ek = 13d99404...   (matches the golden model for the second seed)

### 3. New command 0x40 -- soft reset

The protocol had no way to return the engine to a known state. 0x40 holds the
KEM in reset for 8 cycles; the byte memory and seed memory live in the UART
core and are NOT cleared, so staged inputs survive. Useful for recovering from
a hang without power-cycling the board.

### 1. mlkem_system: rho never written into ek's tail

mlkem_system.sv changed. K-PKE KeyGen produces only the 768 encoded bytes of
t_hat; rho was exported as a wire (rho_out) and NEVER WRITTEN TO MEMORY, so
ek in the byte buffer was 768 correct bytes followed by 32 stale ones. H(ek)
then hashed a corrupted key and everything downstream was wrong.

Simulation missed it because tb_mlkem_full preloads ek into the byte map --
the RTL was never asked to assemble ek itself. It took a board run against a
NIST vector to expose it, which is precisely the argument for doing hardware
validation rather than stopping at simulation.

The board diagnosed it exactly:

    ek differs first at byte 768
    board 30b5000000000000
    NIST  30b5323f422b9fb1

Bytes 0..767 were already byte-exact against NIST -- the whole arithmetic
path was correct; only the rho copy was missing. KeyGen now writes rho into
ek[768:800] before H(ek) is computed.

Verified in simulation against that same NIST vector (tb_nist_kg.sv):

    ek[0:768]  (encoded t_hat): 768/768 match NIST
    ek[768:800] (rho tail):     32/32  match NIST
    dk_pke and H(ek):           match NIST
    PASS -- board-path KeyGen reproduces the NIST vector exactly

and the full KEM regression still passes.

## Build

    New project, part xc7k325tffg900-2
    Design sources: all 28 .sv files
    Constraints:    kc705_mlkem.xdc      (this one ONLY)
    Top:            kc705_mlkem_top

    Synthesis -> Implementation -> CHECK WNS -> Generate Bitstream

*** CHECK WNS BEFORE THE BITSTREAM. ***
mlkem_system alone closed at +0.233 ns -- 2.3% of the 10 ns period. This
wrapper adds the UART core and an 8 KB memory on top. If WNS goes negative,
the cheapest fix is a slower core clock: CLKOUT0_DIVIDE_F 10.000 -> 12.000
(83 MHz) in kc705_mlkem_top.sv, and CLKS_PER_BIT 868 -> 723 to keep 115200
baud. A negative-slack design programs fine and computes silently wrong
values, which is exactly what the staged host checks are built to catch.

## Board setup

  1. 12 V adapter (the KC705 is not USB powered), power on
  2. BOTH USB cables: JTAG, and the separate USB UART (mini-B, Silicon Labs
     CP2103 -- needs the CP210x VCP driver; it is NOT the FTDI "USB Serial
     Converter A/B", those are JTAG)
  3. Hardware Manager -> Open Target -> Auto Connect -> Program Device
  4. DONE LED lights
  5. Note the COM port (Device Manager -> Ports)

## Run

    py -m pip install pyserial kyber-py

    py host_nist.py  COM6 all         # *** official NIST vectors, no deps ***
    py host_mlkem.py COM6 selftest    # FPGA does everything itself
    py host_mlkem.py COM6 reject      # implicit rejection
    py host_mlkem.py COM6 interop     # needs kyber-py (pip install kyber-py)

host_nist.py needs ONLY pyserial. Start with it -- it is both the easiest to
run and the most convincing.

---

# HOW TO DEMONSTRATE THIS

## The framing to lead with

ML-KEM does NOT encrypt data, and is not meant to. It is a Key Encapsulation
Mechanism: it establishes a shared secret, which you then hand to AES-GCM for
bulk encryption. It is the post-quantum replacement for the ECDH half of a
TLS handshake, not for AES. Say this first or people will ask where the
encrypted packets are.

## Weakest to strongest

### 1. Self-test          `host_mlkem.py COM6 selftest`
The board does KeyGen, Encaps and Decaps and both secrets match. Fine, but a
sceptic will note it is your design checked against your own model.

### 2. Provenance         (documentation, already done)
The golden model matches kyber-py byte-for-byte; the twiddle constants match
the FIPS 203 Appendix A table; Barrett reduction is proven exact by
exhaustive check over all 11,075,585 possible products; compress/decompress,
ByteEncode/Decode and cbd3 match the CRYSTALS-Kyber C reference; SHA3 and
SHAKE match FIPS 202 vectors including multi-block cases. Show the chain.

### 3. INTEROPERABILITY   `host_mlkem.py COM6 interop`   <-- USE THIS ONE
The FPGA generates a keypair and performs Decaps. kyber-py -- software
written by someone else -- performs Encaps against the FPGA's public key.
Both print their 32-byte shared secret. They are identical.

    [FPGA]     public key ek = 3995815e597d1043...
    [kyber-py] shared secret = 14cace3e48771b31...
    [FPGA]     shared secret = 14cace3e48771b31...
    PASS -- FPGA and independent software agree on the secret

Two independent implementations, one of them not yours, agreeing. That is
the demonstration. Nobody can dismiss it as self-referential, and it takes
thirty seconds to run in front of an audience.

### 4. Security property  `host_mlkem.py COM6 reject`
Flip one ciphertext bit; the board returns a DIFFERENT secret instead of the
real one, and lights the reject LED. This is the CCA-security property of the
Fujisaki-Okamoto transform -- a design can look entirely functional while
getting it wrong, so showing it working is worth a slide of its own.

### 5. OFFICIAL NIST VECTORS   `host_nist.py COM6 all`   <-- STRONGEST
No internet and no kyber-py needed. nist_vectors.json holds vectors taken
verbatim from usnistgov/ACVP-Server (ML-KEM-keyGen-FIPS203 and
ML-KEM-encapDecap-FIPS203). NIST supplies the inputs and publishes the
expected outputs; the board is given the inputs and its output is compared
byte-for-byte with NIST's.

    NIST supplies (d, z)  -> board must produce NIST's ek and dk
    NIST supplies (dk, c) -> board must produce NIST's shared secret K

Nothing in this test depends on our model being right, which is exactly why
it is the strongest evidence available short of a formal CAVP submission.

The golden model already passes the full published set in simulation:

    NIST ACVP ML-KEM-512 keyGen:        25/25
    NIST ACVP ML-KEM-512 encapsulation: 25/25
    NIST ACVP ML-KEM-512 decapsulation: 10/10

Note the wording to use: passing ACVP vectors is CONFORMANCE EVIDENCE. It is
not the same as a CAVP certificate, which requires submission through an
accredited lab. Say "passes the published NIST ACVP vectors" -- accurate,
strong, and it will not be challenged.

## If you want a visible "secure link" demo

    FPGA --ML-KEM Encaps/Decaps--> shared secret K
                                        |
                            AES-GCM (host software)
                                        |
                                encrypted traffic

Add an AES-GCM step in the host script keyed by the secret the board
established, and you can show real encrypted traffic whose key came from your
hardware. Small amount of work, and it makes the point to a non-specialist
audience immediately.

## What to say about limitations

Say these before someone finds them:
  * ML-KEM-512 is built; TLS deployments use hybrid X25519MLKEM768, which
    needs the 768 parameter set (k=3, eta1=2) and X25519 alongside. The
    parameter set is a re-parameterisation plus new golden vectors, not a
    rewrite.
  * Passes the published NIST ACVP vectors, but is not CAVP-CERTIFIED --
    certification requires submission through an accredited lab.
  * Timing margin at 100 MHz is 2.3%. Real, but thin.
  * Throughput is not optimised: the NTT is a latency pipeline with no
    overlap between butterflies -- roughly 6x is available from overlapping
    alone, before any parallelism.
  * Side channels: verify_cmov is constant-time by construction and its
    timing invariance is asserted in simulation; nothing else has been
    analysed.

Stating these yourself is far stronger than being asked.
