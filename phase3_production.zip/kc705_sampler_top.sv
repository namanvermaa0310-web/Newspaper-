// =============================================================================
// kc705_sampler_top.sv -- KC705 board wrapper (the ONLY board-specific RTL)
// -----------------------------------------------------------------------------
// Everything here is Xilinx-primitive glue: differential clock input, MMCM to
// derive a 100 MHz core clock from the 200 MHz board oscillator, and a reset
// synchronizer. All real logic lives in sampler_uart_core, which is fully
// simulated in Icarus (this file cannot be -- it instantiates UNISIMs).
//
// Board resources used (only 4 pins, all verified against the KC705 master XDC):
//   SYSCLK_P/N  AD12 / AD11   200 MHz differential oscillator, bank 33
//   CPU_RESET   AB7           pushbutton
//   USB_UART    M19 (in) / K24 (out)   USB-to-UART bridge, bank 15
//
// Deliberately NOT pin-mapping the NTT data buses. the sampler exposes wide coefficient buses, and
// address/data I/O and KC705 has 8 LEDs and 4 DIP switches -- there is no
// honest way to drive 16-bit coefficients from board switches. The UART is
// the correct interface, and it is what a production bring-up would use.
// =============================================================================
module kc705_sampler_top (
  input  wire sysclk_p,
  input  wire sysclk_n,
  input  wire cpu_reset,      // KC705 pushbutton, ACTIVE HIGH (see note below)
  input  wire uart_rx,        // from USB-UART bridge into FPGA (pin M19)
  output wire uart_tx         // from FPGA out to USB-UART bridge (pin K24)
);

  // ---------------------------------------------------------------------------
  // 200 MHz differential input -> single-ended
  // ---------------------------------------------------------------------------
  wire sysclk_ibuf;
  IBUFDS #(
    .DIFF_TERM("FALSE"),
    .IBUF_LOW_PWR("FALSE")
  ) u_ibufds_sysclk (
    .I  (sysclk_p),
    .IB (sysclk_n),
    .O  (sysclk_ibuf)
  );

  // ---------------------------------------------------------------------------
  // MMCM: 200 MHz in -> 100 MHz core clock
  // VCO = 200 MHz * 5 / 1 = 1000 MHz  (inside the Kintex-7 -2 VCO range)
  // CLKOUT0 = 1000 / 10 = 100 MHz
  //
  // Running the core at 100 MHz rather than the raw 200 MHz is deliberate:
  // ntt_engine's butterfly path (16x16 multiply + Barrett reduce + conditional
  // subtract, all combinational in one cycle) is unlikely to close timing at
  // 5 ns. Check the post-implementation timing report; if WNS is comfortably
  // positive at 100 MHz you can try raising it, and if it is negative you will
  // need to pipeline the butterfly.
  // ---------------------------------------------------------------------------
  wire clk_fb, clk_fb_buf;
  wire clk100_raw, clk100;
  wire mmcm_locked;

  MMCME2_BASE #(
    .BANDWIDTH          ("OPTIMIZED"),
    .CLKIN1_PERIOD      (5.000),      // 200 MHz
    .DIVCLK_DIVIDE      (1),
    .CLKFBOUT_MULT_F    (5.000),      // VCO = 1000 MHz
    .CLKOUT0_DIVIDE_F   (10.000),     // 100 MHz
    .CLKOUT0_DUTY_CYCLE (0.500),
    .CLKOUT0_PHASE      (0.000),
    .STARTUP_WAIT       ("FALSE")
  ) u_mmcm (
    .CLKIN1   (sysclk_ibuf),
    .CLKFBIN  (clk_fb_buf),
    .CLKFBOUT (clk_fb),
    .CLKOUT0  (clk100_raw),
    .CLKOUT1  (), .CLKOUT2  (), .CLKOUT3 (),
    .CLKOUT4  (), .CLKOUT5  (), .CLKOUT6 (),
    .CLKOUT0B (), .CLKOUT1B (), .CLKOUT2B (), .CLKOUT3B (),
    .CLKFBOUTB(),
    .LOCKED   (mmcm_locked),
    .PWRDWN   (1'b0),
    .RST      (cpu_reset)
  );

  BUFG u_bufg_fb  (.I(clk_fb),     .O(clk_fb_buf));
  BUFG u_bufg_clk (.I(clk100_raw), .O(clk100));

  // ---------------------------------------------------------------------------
  // Reset synchronizer: assert asynchronously, release synchronously to clk100.
  // Held in reset while the MMCM is unlocked or the button is pressed.
  // NOTE: KC705's CPU_RESET pushbutton is active HIGH (pressing drives 1), so
  // it is used directly as the async assert. If your board revision differs,
  // invert it here -- this is the one polarity worth confirming on the bench
  // with a scope or by checking that the design comes out of reset at power-on.
  // ---------------------------------------------------------------------------
  wire async_rst = cpu_reset | ~mmcm_locked;

  (* ASYNC_REG = "TRUE" *) reg rst_meta, rst_sync;
  always @(posedge clk100 or posedge async_rst) begin
    if (async_rst) begin
      rst_meta <= 1'b1;
      rst_sync <= 1'b1;
    end else begin
      rst_meta <= 1'b0;
      rst_sync <= rst_meta;
    end
  end

  wire rst_n = ~rst_sync;

  // ---------------------------------------------------------------------------
  // The verified core. CLKS_PER_BIT = 100 MHz / 115200 baud = 868.
  // ---------------------------------------------------------------------------
  sampler_uart_core #(
    .CLKS_PER_BIT(868)
  ) u_core (
    .clk       (clk100),
    .rst_n     (rst_n),
    .uart_rx_i (uart_rx),
    .uart_tx_o (uart_tx)
  );

endmodule : kc705_sampler_top
