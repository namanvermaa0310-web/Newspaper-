#!/usr/bin/env python3
"""
host_sampler.py -- host-side bench driver for the KC705 FIPS 203 sampler.

Loads rho and sigma over the UART, runs the hardware sampling pipeline, reads
back all 512 coefficients, and checks them against a Python implementation of
the FIPS 203 algorithms:

    A_hat[i][j] = SampleNTT( SHAKE-128( rho || j || i ) )     Algorithm 7
    s           = SamplePolyCBD_2( SHAKE-256( sigma || N ) )  Algorithm 8
    s_hat       = NTT( s )                                    Algorithm 9

Usage (Windows):
    py -m pip install pyserial
    py host_sampler.py COM6

Usage (Linux):
    python3 host_sampler.py /dev/ttyUSB0
"""

import sys
import time
import hashlib

try:
    import serial
except ImportError:
    sys.exit("pyserial not installed.  Run:  py -m pip install pyserial")

BAUD = 115200
Q = 3329

C_PING  = 0xA5
PING_OK = 0x5A
C_SEED  = 0x50
C_IDX   = 0x51
C_GO    = 0x52
C_STAT  = 0x53
C_RD_A  = 0x54
C_RD_S  = 0x55


# -----------------------------------------------------------------------------
# FIPS 203 reference model
# -----------------------------------------------------------------------------
def sample_ntt(xof_bytes):
    """Algorithm 7: rejection sampling to 256 uniform coefficients mod q."""
    a = []
    idx = 0
    while len(a) < 256:
        b0, b1, b2 = xof_bytes[idx], xof_bytes[idx + 1], xof_bytes[idx + 2]
        idx += 3
        d1 = b0 + 256 * (b1 % 16)
        d2 = (b1 // 16) + 16 * b2
        if d1 < Q:
            a.append(d1)
        if d2 < Q and len(a) < 256:
            a.append(d2)
    return a


def sample_poly_cbd2(prf_bytes):
    """Algorithm 8: centered binomial distribution, eta = 2."""
    bits = [(byte >> k) & 1 for byte in prf_bytes for k in range(8)]
    return [(bits[4 * i] + bits[4 * i + 1]
             - bits[4 * i + 2] - bits[4 * i + 3]) % Q for i in range(256)]


def br7(i):
    return int(f"{i:07b}"[::-1], 2)


ZETAS = [pow(17, br7(i), Q) for i in range(128)]


def ntt(f):
    """Algorithm 9."""
    f = list(f)
    i = 1
    length = 128
    while length >= 2:
        for start in range(0, 256, 2 * length):
            z = ZETAS[i]
            i += 1
            for j in range(start, start + length):
                t = (z * f[j + length]) % Q
                f[j + length] = (f[j] - t) % Q
                f[j] = (f[j] + t) % Q
        length //= 2
    return f


# -----------------------------------------------------------------------------
class Sampler:
    def __init__(self, port):
        self.ser = serial.Serial(port, BAUD, timeout=2.0)
        time.sleep(0.2)
        self.ser.reset_input_buffer()

    def _expect(self, want, what):
        got = self.ser.read(1)
        if not got:
            raise TimeoutError(f"{what}: no reply (timeout)")
        if got[0] != want:
            raise ValueError(f"{what}: got 0x{got[0]:02X}, expected 0x{want:02X}")

    def ping(self, retries=3):
        # The first PING after opening the port can be lost: opening a COM port
        # toggles DTR/RTS on many USB-UART bridges, and the FPGA may still be
        # settling. Retry rather than fail the whole run on a benign first miss.
        for attempt in range(retries):
            try:
                self.ser.reset_input_buffer()
                self.ser.write(bytes([C_PING]))
                self._expect(PING_OK, "PING")
                return attempt
            except (TimeoutError, ValueError):
                if attempt == retries - 1:
                    raise
                time.sleep(0.3)

    def write_seed(self, addr, value):
        self.ser.write(bytes([C_SEED, addr, value]))
        self._expect(C_SEED, f"SEED[{addr}]")

    def set_indices(self, i, j, n):
        self.ser.write(bytes([C_IDX, i, j, n]))
        self._expect(C_IDX, "INDICES")

    def start(self):
        self.ser.write(bytes([C_GO]))
        self._expect(C_GO, "START")

    def status(self):
        self.ser.write(bytes([C_STAT]))
        b = self.ser.read(1)
        if not b:
            raise TimeoutError("STATUS: no reply")
        return {"busy": bool(b[0] & 0x01),
                "done": bool(b[0] & 0x02),
                "error": bool(b[0] & 0x04)}

    def wait_done(self, timeout_s=10.0):
        t0 = time.time()
        while time.time() - t0 < timeout_s:
            st = self.status()
            if st["error"]:
                raise RuntimeError("SampleNTT reported XOF stream exhaustion")
            if not st["busy"] and st["done"]:
                return
        raise TimeoutError("pipeline never reported done")

    def _read16(self, cmd, idx, what):
        self.ser.write(bytes([cmd, idx]))
        b = self.ser.read(2)
        if len(b) != 2:
            raise TimeoutError(f"{what}[{idx}]: short reply")
        return b[0] | (b[1] << 8)

    def read_a(self, idx):
        return self._read16(C_RD_A, idx, "A_hat")

    def read_s(self, idx):
        return self._read16(C_RD_S, idx, "s_hat")


def compare(label, read_fn, expected):
    print(f"Reading {label} and comparing to FIPS 203 reference...",
          end=" ", flush=True)
    errs = 0
    for i in range(256):
        got = read_fn(i)
        if got != expected[i]:
            if errs < 10:
                print(f"\n  {label}[{i}]: got {got}, expected {expected[i]}")
            errs += 1
    if errs == 0:
        print("ok, 256/256")
    return errs


def main():
    if len(sys.argv) != 2:
        sys.exit(f"usage: {sys.argv[0]} <serial-port>")
    port = sys.argv[1]

    print(f"Opening {port} at {BAUD} baud...")
    acc = Sampler(port)

    print("PING...", end=" ", flush=True)
    tries = acc.ping()
    print("ok, link alive" + (f" (after {tries} retr{'y' if tries==1 else 'ies'})"
                              if tries else ""))

    st = acc.status()
    print(f"STATUS: busy={st['busy']} done={st['done']} error={st['error']}")

    # rho = 0x00..0x1F, sigma = 0x20..0x3F -- same vector as every testbench,
    # so a hardware failure is directly comparable to the simulation result.
    rho = bytes(range(32))
    sigma = bytes(range(32, 64))

    print("Loading seed (rho || sigma, 64 bytes)...", end=" ", flush=True)
    for i in range(64):
        acc.write_seed(i, i)
    print("done")

    acc.set_indices(0, 0, 0)
    print("Indices set: i=0, j=0, N=0")

    print("Running sampler pipeline on hardware...", end=" ", flush=True)
    t0 = time.time()
    acc.start()
    acc.wait_done()
    elapsed = time.time() - t0
    print(f"done ({elapsed*1000:.1f} ms wall clock, incl. UART polling)")

    exp_a = sample_ntt(hashlib.shake_128(rho + bytes([0, 0])).digest(672))
    s = sample_poly_cbd2(hashlib.shake_256(sigma + bytes([0])).digest(128))
    exp_s = ntt(s)

    errs = compare("A_hat", acc.read_a, exp_a)
    errs += compare("s_hat", acc.read_s, exp_s)

    print()
    print("=" * 60)
    if errs == 0:
        print("  PASS -- hardware sampler matches FIPS 203")
        print("  512/512 coefficients correct on real silicon")
        print("  (SampleNTT Alg 7, SamplePolyCBD_2 Alg 8, NTT Alg 9)")
        print("=" * 60)
        return 0
    else:
        print(f"  FAIL -- {errs}/512 coefficients wrong")
        print("=" * 60)
        print("If A_hat is wrong but s_hat is right, suspect SHAKE-128 or the")
        print("SampleNTT rejection loop. If s_hat is wrong but A_hat is right,")
        print("suspect SHAKE-256, the CBD sampler, or the NTT. If both are")
        print("wrong, suspect the shared Keccak permutation or timing closure.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
