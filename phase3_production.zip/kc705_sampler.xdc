## =============================================================================
## kc705_mlkem.xdc -- constraints for kc705_sampler_top
## Target: xc7k325tffg900-2 (Kintex-7 KC705 Evaluation Board)
## =============================================================================
## Only 4 pins are constrained, and every one is a real, documented KC705
## board net cross-checked against the Xilinx KC705 master XDC (UG810 App. C).
## This is the whole point of the UART wrapper: instead of inventing pin
## locations for 48 bits of coefficient bus that the board cannot physically
## drive, the design talks over the USB-UART bridge that is already wired.
## =============================================================================

## -----------------------------------------------------------------------------
## SYSCLK -- 200 MHz differential oscillator (SiT9102), bank 33
## -----------------------------------------------------------------------------
set_property PACKAGE_PIN AD12 [get_ports sysclk_p]
set_property PACKAGE_PIN AD11 [get_ports sysclk_n]
set_property IOSTANDARD LVDS  [get_ports sysclk_p]
set_property IOSTANDARD LVDS  [get_ports sysclk_n]

## KNOWN GOTCHA: bank 33 is a 1.5 V HP bank. In some Vivado versions the plain
## LVDS standard is rejected for this bank and you must use DIFF_SSTL15
## instead. UG810's master XDC says LVDS; several working KC705 projects use
## DIFF_SSTL15. If synthesis or implementation errors on the IOSTANDARD,
## comment out the two LVDS lines above and use these instead:
#set_property IOSTANDARD DIFF_SSTL15 [get_ports sysclk_p]
#set_property IOSTANDARD DIFF_SSTL15 [get_ports sysclk_n]

create_clock -period 5.000 -name sysclk -waveform {0.000 2.500} [get_ports sysclk_p]

## -----------------------------------------------------------------------------
## CPU_RESET pushbutton, bank 34 (1.5 V)
## -----------------------------------------------------------------------------
set_property PACKAGE_PIN AB7      [get_ports cpu_reset]
set_property IOSTANDARD LVCMOS15  [get_ports cpu_reset]

## -----------------------------------------------------------------------------
## USB-UART bridge (Silicon Labs CP210x), bank 15 (2.5 V)
## Direction naming is from the FPGA's point of view:
##   uart_rx (M19) -- the bridge's TX, an INPUT to the FPGA
##   uart_tx (K24) -- the bridge's RX, an OUTPUT from the FPGA
## -----------------------------------------------------------------------------
set_property PACKAGE_PIN M19      [get_ports uart_rx]
set_property IOSTANDARD LVCMOS25  [get_ports uart_rx]

set_property PACKAGE_PIN K24      [get_ports uart_tx]
set_property IOSTANDARD LVCMOS25  [get_ports uart_tx]

## NOTE (Xilinx AR 45934): the UART pin assignments K24/M19 in UG810's XDC do
## not match Vivado's part0_pins.xml board file. The values above follow UG810
## and multiple independently-working KC705 projects. If the UART does not
## enumerate on the bench, this discrepancy is the first thing to check, and
## swapping M19/K24 is the first thing to try.

## -----------------------------------------------------------------------------
## Timing exceptions
## -----------------------------------------------------------------------------
## UART lines are asynchronous to the core clock. uart_rx is double-flopped
## inside uart_rx.sv, so there is no meaningful setup/hold relationship to
## constrain; telling the tool that avoids bogus unconstrained-path warnings.
set_false_path -from [get_ports uart_rx]
set_false_path -to   [get_ports uart_tx]

## The reset pushbutton is asynchronous and is passed through a two-stage
## synchronizer (rst_meta -> rst_sync) in kc705_sampler_top.
set_false_path -from [get_ports cpu_reset]

## -----------------------------------------------------------------------------
## Configuration
## -----------------------------------------------------------------------------
set_property CFGBVS VCCO        [current_design]
set_property CONFIG_VOLTAGE 2.5 [current_design]

## =============================================================================
## WHAT TO VERIFY BEFORE TRUSTING THIS ON HARDWARE
## =============================================================================
## 1. CPU_RESET polarity. The wrapper assumes ACTIVE HIGH (pressing the button
##    drives 1). If the design never leaves reset at power-on, invert
##    `async_rst` in kc705_sampler_top.sv.
## 2. The sysclk IOSTANDARD (see the gotcha above).
## 3. The UART pin swap (AR 45934, see above).
## 4. Post-implementation timing. Open the Timing Summary and confirm WNS is
##    positive on the 100 MHz clock. ntt_engine's butterfly is one long
##    combinational path (16x16 multiply + Barrett + conditional subtract);
##    if WNS is negative, pipeline the butterfly rather than dropping the
##    clock frequency further.
## 5. Resource utilisation. Expect this to be small (a few thousand LUTs and
##    a handful of BRAMs for the 256x16 coefficient memory) -- if it is
##    dramatically larger, check that coeff_mem inferred as block RAM and not
##    as distributed registers.
## =============================================================================
