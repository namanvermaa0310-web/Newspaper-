// =============================================================================
// uart_tx.sv -- 8N1 UART transmitter
// Assert `send` for one cycle with `data` valid; `busy` stays high until the
// stop bit has been driven. Ignores `send` while busy.
// =============================================================================
module uart_tx #(
  parameter integer CLKS_PER_BIT = 868
)(
  input  wire       clk,
  input  wire       rst_n,
  input  wire       send,
  input  wire [7:0] data,
  output reg        tx,
  output reg        busy
);
  localparam ST_IDLE  = 2'd0;
  localparam ST_START = 2'd1;
  localparam ST_DATA  = 2'd2;
  localparam ST_STOP  = 2'd3;

  reg [1:0]  state;
  reg [15:0] cnt;
  reg [2:0]  bit_idx;
  reg [7:0]  shreg;

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= ST_IDLE; cnt <= 16'd0; bit_idx <= 3'd0;
      shreg <= 8'd0; tx <= 1'b1; busy <= 1'b0;
    end else begin
      case (state)
        ST_IDLE: begin
          tx <= 1'b1; cnt <= 16'd0; bit_idx <= 3'd0;
          if (send) begin
            shreg <= data;
            busy  <= 1'b1;
            tx    <= 1'b0;                 // start bit
            state <= ST_START;
          end else busy <= 1'b0;
        end

        ST_START: begin
          if (cnt == (CLKS_PER_BIT-1)) begin
            cnt   <= 16'd0;
            tx    <= shreg[0];
            shreg <= {1'b0, shreg[7:1]};
            state <= ST_DATA;
          end else cnt <= cnt + 16'd1;
        end

        ST_DATA: begin
          if (cnt == (CLKS_PER_BIT-1)) begin
            cnt <= 16'd0;
            if (bit_idx == 3'd7) begin
              tx <= 1'b1;                  // stop bit
              bit_idx <= 3'd0;
              state <= ST_STOP;
            end else begin
              tx    <= shreg[0];
              shreg <= {1'b0, shreg[7:1]};
              bit_idx <= bit_idx + 3'd1;
            end
          end else cnt <= cnt + 16'd1;
        end

        ST_STOP: begin
          if (cnt == (CLKS_PER_BIT-1)) begin
            cnt   <= 16'd0;
            busy  <= 1'b0;
            state <= ST_IDLE;
          end else cnt <= cnt + 16'd1;
        end
      endcase
    end
  end
endmodule : uart_tx
