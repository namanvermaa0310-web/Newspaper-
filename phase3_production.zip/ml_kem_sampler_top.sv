// =============================================================================
// ml_kem_sampler_top.sv -- Phase 3 (NIST-aligned): K-PKE KeyGen inner data path
// -----------------------------------------------------------------------------
// Implements, exactly per FIPS 203, the generation of:
//
//   A_hat[i][j] = SampleNTT( SHAKE-128( rho || j || i ) )     [Algorithms 7]
//   s           = SamplePolyCBD_eta2( SHAKE-256( sigma || N ) )  [Algorithm 8]
//   s_hat       = NTT( s )                                    [Algorithm 9]
//
// for ONE matrix entry (i, j) and ONE secret polynomial (index N). This is
// the exact inner loop of K-PKE.KeyGen (Algorithm 13); the full KeyGen
// repeats it k*k times for the matrix and k times for s and e, then computes
// t_hat = A_hat o s_hat + e_hat -- which additionally needs the basecase
// (pointwise, degree-2) multiplier of Algorithms 11/12, not yet built.
//
// Byte ordering note: FIPS 203 (final, Aug 2024) matches Kyber round 3:
// the XOF input is rho || j || i (column index first). The i/j inputs
// below are appended in that order.
//
// Seed layout (seed_wr port, write while IDLE):
//   bytes  0..31 : rho    (public matrix seed)
//   bytes 32..63 : sigma  (noise seed)
// =============================================================================
module ml_kem_sampler_top (
  input  wire         clk,
  input  wire         rst_n,
  input  wire         start,

  input  wire [7:0]   mat_i,        // matrix row index    (appended second)
  input  wire [7:0]   mat_j,        // matrix column index (appended first)
  input  wire [7:0]   prf_n,        // PRF domain counter N for the CBD draw

  // Seed load interface (64 bytes: rho || sigma)
  input  wire [5:0]   seed_wr_addr,
  input  wire [7:0]   seed_wr_data,
  input  wire         seed_wr_en,

  // A_hat[i][j] coefficient readout (valid after done)
  input  wire [7:0]   a_rd_addr,
  output wire [15:0]  a_rd_data,

  // s_hat coefficient readout (valid after done; reads NTT memory)
  input  wire [7:0]   s_rd_addr,
  output wire [15:0]  s_rd_data,

  output reg          busy,
  output reg          done,
  output wire         sample_error   // SampleNTT stream exhaustion (never expected)
);

  // ---------------------------------------------------------------------------
  // Seed storage
  // ---------------------------------------------------------------------------
  reg [7:0] seed_mem [0:63];
  always @(posedge clk) begin
    if (seed_wr_en) seed_mem[seed_wr_addr] <= seed_wr_data;
  end

  // ---------------------------------------------------------------------------
  // SHAKE-128: XOF for matrix sampling. msg = rho || j || i (34 bytes),
  // output 672 bytes (4 rate-blocks) -- enough for SampleNTT w.h.p.
  // ---------------------------------------------------------------------------
  reg          s128_start;
  reg  [8:0]   s128_wr_addr;
  reg  [7:0]   s128_wr_data;
  reg          s128_wr_en;
  wire [9:0]   s128_rd_addr;
  wire [7:0]   s128_rd_data;
  wire         s128_busy, s128_done;

  shake128 #(.MAX_MSG_BYTES(64), .MAX_OUT_BYTES(672)) u_shake128 (
    .clk(clk), .rst_n(rst_n), .start(s128_start),
    .msg_len(10'd34),
    .wr_addr(s128_wr_addr), .wr_data(s128_wr_data), .wr_en(s128_wr_en),
    .out_len(10'd672),
    .busy(s128_busy), .done(s128_done),
    .rd_addr(s128_rd_addr), .rd_data(s128_rd_data)
  );

  // ---------------------------------------------------------------------------
  // SampleNTT (Algorithm 7) -> A_hat[i][j] memory
  // ---------------------------------------------------------------------------
  reg          sntt_start;
  wire [7:0]   sntt_wr_addr;
  wire [15:0]  sntt_wr_data;
  wire         sntt_wr_en;
  wire         sntt_busy, sntt_done;

  sample_ntt u_sample_ntt (
    .clk(clk), .rst_n(rst_n), .start(sntt_start),
    .stream_len(10'd672),
    .byte_rd_addr(s128_rd_addr), .byte_rd_data(s128_rd_data),
    .coeff_wr_addr(sntt_wr_addr), .coeff_wr_data(sntt_wr_data),
    .coeff_wr_en(sntt_wr_en),
    .busy(sntt_busy), .done(sntt_done), .error(sample_error)
  );

  reg [15:0] a_hat_mem [0:255];
  always @(posedge clk) begin
    if (sntt_wr_en) a_hat_mem[sntt_wr_addr] <= sntt_wr_data;
  end
  assign a_rd_data = a_hat_mem[a_rd_addr];

  // ---------------------------------------------------------------------------
  // SHAKE-256: PRF for noise. msg = sigma || N (33 bytes), output 128 bytes.
  // ---------------------------------------------------------------------------
  reg          s256_start;
  reg  [8:0]   s256_wr_addr;
  reg  [7:0]   s256_wr_data;
  reg          s256_wr_en;
  wire [9:0]   s256_rd_addr_w;
  wire [7:0]   s256_rd_data;
  wire         s256_busy, s256_done;
  wire [6:0]   cbd_rd_addr;

  assign s256_rd_addr_w = {3'd0, cbd_rd_addr};

  shake256 #(.MAX_MSG_BYTES(64), .MAX_OUT_BYTES(272)) u_shake256 (
    .clk(clk), .rst_n(rst_n), .start(s256_start),
    .msg_len(10'd33),
    .wr_addr(s256_wr_addr), .wr_data(s256_wr_data), .wr_en(s256_wr_en),
    .out_len(10'd128),
    .busy(s256_busy), .done(s256_done),
    .rd_addr(s256_rd_addr_w), .rd_data(s256_rd_data)
  );

  // ---------------------------------------------------------------------------
  // CBD sampler (Algorithm 8, eta=2) -> writes s into the NTT engine
  // ---------------------------------------------------------------------------
  reg          cbd_start;
  wire [7:0]   cbd_wr_addr;
  wire [15:0]  cbd_wr_data;
  wire         cbd_wr_en;
  wire         cbd_busy, cbd_done;

  cbd_sampler u_cbd (
    .clk(clk), .rst_n(rst_n), .start(cbd_start),
    .byte_rd_addr(cbd_rd_addr), .byte_rd_data(s256_rd_data),
    .coeff_wr_addr(cbd_wr_addr), .coeff_wr_data(cbd_wr_data),
    .coeff_wr_en(cbd_wr_en),
    .busy(cbd_busy), .done(cbd_done)
  );

  // ---------------------------------------------------------------------------
  // NTT engine (Phase 1): s -> s_hat  (FIPS 203 Algorithm 9)
  // ---------------------------------------------------------------------------
  reg          ntt_start;
  wire         ntt_busy, ntt_done;

  ntt_engine u_ntt (
    .clk(clk), .rst_n(rst_n), .start(ntt_start), .mode(1'b0),  // forward NTT
    .done(ntt_done), .busy(ntt_busy),
    .wr_addr(cbd_wr_addr), .wr_data(cbd_wr_data), .wr_en(cbd_wr_en),
    .rd_addr(s_rd_addr), .rd_data(s_rd_data)
  );

  // ---------------------------------------------------------------------------
  // Orchestration FSM
  // ---------------------------------------------------------------------------
  localparam ST_IDLE       = 4'd0;
  localparam ST_CP1        = 4'd1;   // copy rho||j||i into shake128 buffer
  localparam ST_S128_GO    = 4'd2;
  localparam ST_S128_KICK  = 4'd3;
  localparam ST_S128_RUN   = 4'd4;
  localparam ST_SNTT_KICK  = 4'd5;
  localparam ST_SNTT_RUN   = 4'd6;
  localparam ST_CP2        = 4'd7;   // copy sigma||N into shake256 buffer
  localparam ST_S256_GO    = 4'd8;
  localparam ST_S256_KICK  = 4'd9;
  localparam ST_S256_RUN   = 4'd10;
  localparam ST_CBD_KICK   = 4'd11;
  localparam ST_CBD_RUN    = 4'd12;
  localparam ST_NTT_KICK   = 4'd13;
  localparam ST_NTT_RUN    = 4'd14;
  localparam ST_DONE       = 4'd15;

  reg [3:0] state;
  reg [5:0] cp;   // copy counter

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= ST_IDLE; busy <= 1'b0; done <= 1'b0;
      s128_start <= 1'b0; s128_wr_addr <= 9'd0; s128_wr_data <= 8'd0; s128_wr_en <= 1'b0;
      sntt_start <= 1'b0;
      s256_start <= 1'b0; s256_wr_addr <= 9'd0; s256_wr_data <= 8'd0; s256_wr_en <= 1'b0;
      cbd_start <= 1'b0; ntt_start <= 1'b0;
      cp <= 6'd0;
    end else begin
      s128_start <= 1'b0; sntt_start <= 1'b0; s256_start <= 1'b0;
      cbd_start  <= 1'b0; ntt_start  <= 1'b0;
      s128_wr_en <= 1'b0; s256_wr_en <= 1'b0;

      case (state)
        ST_IDLE: begin
          if (start) begin
            busy <= 1'b1; done <= 1'b0; cp <= 6'd0;
            state <= ST_CP1;
          end
        end

        // ---- rho || j || i  ->  shake128 message buffer (34 bytes) --------
        ST_CP1: begin
          s128_wr_addr <= {3'd0, cp};
          s128_wr_data <= (cp < 6'd32) ? seed_mem[cp] :
                          (cp == 6'd32) ? mat_j : mat_i;
          s128_wr_en   <= 1'b1;
          if (cp == 6'd33) begin
            cp <= 6'd0;
            state <= ST_S128_GO;
          end else cp <= cp + 6'd1;
        end
        ST_S128_GO:   begin s128_start <= 1'b1; state <= ST_S128_KICK; end
        ST_S128_KICK: state <= ST_S128_RUN;
        ST_S128_RUN:  if (s128_done) begin sntt_start <= 1'b1; state <= ST_SNTT_KICK; end

        // ---- SampleNTT -> a_hat_mem ---------------------------------------
        ST_SNTT_KICK: state <= ST_SNTT_RUN;
        ST_SNTT_RUN:  if (sntt_done) begin cp <= 6'd0; state <= ST_CP2; end

        // ---- sigma || N  ->  shake256 message buffer (33 bytes) -----------
        ST_CP2: begin
          s256_wr_addr <= {3'd0, cp};
          s256_wr_data <= (cp < 6'd32) ? seed_mem[6'd32 + cp] : prf_n;
          s256_wr_en   <= 1'b1;
          if (cp == 6'd32) begin
            cp <= 6'd0;
            state <= ST_S256_GO;
          end else cp <= cp + 6'd1;
        end
        ST_S256_GO:   begin s256_start <= 1'b1; state <= ST_S256_KICK; end
        ST_S256_KICK: state <= ST_S256_RUN;
        ST_S256_RUN:  if (s256_done) begin cbd_start <= 1'b1; state <= ST_CBD_KICK; end

        // ---- CBD -> ntt coeff_mem -----------------------------------------
        ST_CBD_KICK: state <= ST_CBD_RUN;
        ST_CBD_RUN:  if (cbd_done) begin ntt_start <= 1'b1; state <= ST_NTT_KICK; end

        // ---- NTT: s -> s_hat ----------------------------------------------
        ST_NTT_KICK: state <= ST_NTT_RUN;
        ST_NTT_RUN:  if (ntt_done) begin busy <= 1'b0; done <= 1'b1; state <= ST_DONE; end

        ST_DONE: begin
          done <= 1'b1;
          if (start) begin
            busy <= 1'b1; done <= 1'b0; cp <= 6'd0;
            state <= ST_CP1;
          end
        end

        default: state <= ST_IDLE;
      endcase
    end
  end
endmodule : ml_kem_sampler_top
