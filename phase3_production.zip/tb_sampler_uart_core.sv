`timescale 1ns/1ps
// =============================================================================
// tb_sampler_uart_core.sv -- Phase 3 board-path test over real serial waveforms
// Loads rho||sigma, runs the FIPS 203 sampler pipeline, reads back all 512
// coefficients (A_hat and s_hat) and compares to the Python reference vectors.
// =============================================================================
module tb_sampler_uart_core;
  localparam integer CPB = 16;
  reg clk = 0, rst_n = 0;
  reg  host_tx = 1'b1;
  wire fpga_tx;

  sampler_uart_core #(.CLKS_PER_BIT(CPB)) dut (
    .clk(clk), .rst_n(rst_n), .uart_rx_i(host_tx), .uart_tx_o(fpga_tx)
  );
  always #5 clk = ~clk;

  reg [15:0] golden_ahat [0:255];
  reg [15:0] golden_shat [0:255];
  integer errors = 0;
  integer k;
  reg [7:0]  got;
  reg [15:0] got16;

  task host_send(input [7:0] b);
    integer i;
    begin
      host_tx = 1'b0; repeat (CPB) @(posedge clk);
      for (i=0;i<8;i=i+1) begin host_tx=b[i]; repeat(CPB) @(posedge clk); end
      host_tx = 1'b1; repeat (CPB) @(posedge clk);
    end
  endtask

  reg [7:0] rxq [0:8191];
  integer rxq_wr = 0, rxq_rd = 0;
  initial begin : mon
    reg [7:0] b; integer i;
    forever begin
      @(negedge fpga_tx);
      repeat (CPB + CPB/2) @(posedge clk);
      for (i=0;i<8;i=i+1) begin
        b[i] = fpga_tx;
        if (i<7) repeat(CPB) @(posedge clk);
      end
      rxq[rxq_wr]=b; rxq_wr=rxq_wr+1;
      repeat (CPB) @(posedge clk);
    end
  end
  task host_recv(output [7:0] b);
    begin
      while (rxq_rd == rxq_wr) @(posedge clk);
      b = rxq[rxq_rd]; rxq_rd = rxq_rd + 1;
    end
  endtask

  initial begin
    $readmemh("golden_ahat.hex", golden_ahat);
    $readmemh("golden_shat.hex", golden_shat);
    $display("============================================================");
    $display("  Phase 3 UART board-path test: FIPS 203 sampler pipeline");
    $display("============================================================");

    rst_n=0; repeat(10) @(posedge clk); rst_n=1; repeat(10) @(posedge clk);

    // ---- PING ----
    host_send(8'hA5); host_recv(got);
    if (got !== 8'h5A) begin
      $display("[TB] FAIL ping: got %02h", got); errors=errors+1;
    end else $display("[TB] PING ok (link alive)");

    // ---- load seed: rho = 0x00..0x1F, sigma = 0x20..0x3F ----
    for (k=0;k<64;k=k+1) begin
      host_send(8'h50); host_send(k[7:0]); host_send(k[7:0]);
      host_recv(got);
    end
    $display("[TB] seed loaded (rho || sigma, 64 bytes)");

    // ---- indices: i=0, j=0, N=0 ----
    host_send(8'h51); host_send(8'd0); host_send(8'd0); host_send(8'd0);
    host_recv(got);

    // ---- start ----
    host_send(8'h52); host_recv(got);
    $display("[TB] pipeline started");

    // ---- poll status ----
    got = 8'h01; k = 0;
    while (got[0] === 1'b1 && k < 2000) begin
      host_send(8'h53); host_recv(got); k = k + 1;
    end
    if (got[2] === 1'b1) begin
      $display("[TB] FAIL: SampleNTT reported stream exhaustion"); errors=errors+1;
    end
    if (got[1] !== 1'b1) begin
      $display("[TB] FAIL: never completed (status=%02h after %0d polls)", got, k);
      errors=errors+1;
    end else $display("[TB] pipeline done after %0d status polls", k);

    // ---- read A_hat ----
    for (k=0;k<256;k=k+1) begin
      host_send(8'h54); host_send(k[7:0]);
      host_recv(got16[7:0]); host_recv(got16[15:8]);
      if (got16 !== golden_ahat[k]) begin
        if (errors<8) $display("[TB] A_hat[%0d]: got %0d want %0d",k,got16,golden_ahat[k]);
        errors=errors+1;
      end
    end
    $display("[TB] A_hat: 256/256 read back (SampleNTT, Alg 7)");

    // ---- read s_hat ----
    for (k=0;k<256;k=k+1) begin
      host_send(8'h55); host_send(k[7:0]);
      host_recv(got16[7:0]); host_recv(got16[15:8]);
      if (got16 !== golden_shat[k]) begin
        if (errors<8) $display("[TB] s_hat[%0d]: got %0d want %0d",k,got16,golden_shat[k]);
        errors=errors+1;
      end
    end
    $display("[TB] s_hat: 256/256 read back (CBD Alg 8 -> NTT Alg 9)");

    $display("============================================================");
    if (errors==0)
      $display("  PASS -- 512/512 coefficients match FIPS 203 over UART");
    else
      $display("  FAIL -- %0d error(s)", errors);
    $display("============================================================");
    $finish;
  end
  initial begin #900_000_000; $display("[TB] TIMEOUT state=%0d",dut.state); $finish; end
endmodule
