# Phase 3 Production: FIPS 203 Sampler Pipeline on KC705

Same architecture as Phases 1 and 2. Wraps `ml_kem_sampler_top`, which
implements the inner data path of FIPS 203 K-PKE.KeyGen for one matrix entry
and one secret polynomial:

    A_hat[i][j] = SampleNTT( SHAKE-128( rho || j || i ) )     Algorithm 7
    s           = SamplePolyCBD_2( SHAKE-256( sigma || N ) )  Algorithm 8
    s_hat       = NTT( s )                                    Algorithm 9

This is the first phase where all three engines run together: Keccak feeds the
samplers, the samplers feed the NTT.

## Verified
Icarus, driving real serial waveforms (no backdoor memory access):

    [TB] PING ok (link alive)
    [TB] seed loaded (rho || sigma, 64 bytes)
    [TB] pipeline started
    [TB] pipeline done after 24 status polls
    [TB] A_hat: 256/256 read back (SampleNTT, Alg 7)
    [TB] s_hat: 256/256 read back (CBD Alg 8 -> NTT Alg 9)
    PASS -- 512/512 coefficients match FIPS 203 over UART

Also confirmed: the sampler still passes 768/768 against the standalone Phase 3
testbench after `ntt_engine` was rewritten as a 10-state pipeline for Phase 1
timing closure. The deeper NTT pipeline did not break the integration.

## Files (20)
| File | Role | Simulated? |
|---|---|---|
| mlkem_pkg.sv, twiddle_rom.sv, ntt_engine.sv | Phase 1 NTT (pipelined version) | yes |
| keccak_pkg.sv, keccak_round.sv, keccak_f1600.sv | Phase 2 Keccak permutation | yes |
| shake128.sv | rate 168 XOF, for matrix expansion | yes |
| shake256.sv | rate 136 XOF, for the noise PRF | yes |
| sample_ntt.sv | Algorithm 7 rejection sampler | yes |
| cbd_sampler.sv | Algorithm 8, eta=2 | yes |
| ml_kem_sampler_top.sv | orchestrator FSM | yes |
| uart_rx.sv, uart_tx.sv | 8N1 serial (identical to Phases 1/2) | yes |
| sampler_uart_core.sv | command FSM, board-independent | yes |
| kc705_sampler_top.sv | IBUFDS + MMCM + reset sync | no -- Vivado only |
| tb_sampler_uart_core.sv | end-to-end serial testbench | -- |
| kc705_sampler.xdc | same 4 verified pins as Phases 1/2 | -- |
| host_sampler.py | PC-side bench driver | -- |
| golden_ahat.hex, golden_shat.hex | FIPS 203 reference vectors | -- |

## Command protocol
| Bytes (host -> FPGA) | Meaning | Reply |
|---|---|---|
| `A5` | ping | `5A` |
| `50 addr data` | write seed byte (0..31 rho, 32..63 sigma) | `50` |
| `51 i j N` | set matrix indices and PRF counter | `51` |
| `52` | start pipeline | `52` |
| `53` | status | `{5'b0, error, done, busy}` |
| `54 idx` | read A_hat[idx] | `lo hi` |
| `55 idx` | read s_hat[idx] | `lo hi` |

Status bit 2 is `sample_error` -- SampleNTT exhausting its 672-byte SHAKE-128
stream before accepting 256 coefficients. Astronomically unlikely, but
surfaced rather than hidden: silently returning wrong coefficients is worse
than reporting a failure.

## Complete steps

### 1. Simulate first (Vivado XSim)
1. New project, part `xc7k325tffg900-2`
2. Design sources: all 15 `.sv` files except `tb_sampler_uart_core.sv`
3. Simulation source: `tb_sampler_uart_core.sv`
4. Constraints: `kc705_sampler.xdc`
5. Copy `golden_ahat.hex` and `golden_shat.hex` into
   `<project>.sim/sim_1/behav/xsim/`
6. Set `tb_sampler_uart_core` as **simulation** top
7. Run Behavioral Simulation, then in the console: `run 5ms`
   (the default 1 us is far too short -- this bit-bangs real UART)
8. Expect the PASS banner above

### 2. Synthesis and implementation
1. Set `kc705_sampler_top` as **design** top
2. Run Synthesis
3. Run Implementation
4. **Report Timing Summary -- confirm WNS is positive before going further**

### 3. Bitstream and board
1. Generate Bitstream
2. Power the KC705 (12 V adapter -- it is not USB powered)
3. Connect both USB cables: JTAG, and the separate USB UART (mini-B)
4. Hardware Manager -> Open Target -> Auto Connect -> Program Device
5. DONE LED should light

### 4. Bench test
    py -m pip install pyserial
    py host_sampler.py COM6

Substitute your COM port (Device Manager -> Ports). Expect:

    PASS -- hardware sampler matches FIPS 203
    512/512 coefficients correct on real silicon

## Timing expectation -- check before assuming
Phase 1 needed three rounds of pipelining to close timing. Phase 3 combines
that (now-fixed) NTT with the Keccak permutation, so the worst path is most
likely inside `keccak_round`, which computes theta, rho+pi, chi and iota
across the full 1600-bit state combinationally.

**Check WNS after implementation.** If negative, split `keccak_round` so
theta+rho+pi lands in one cycle and chi+iota in the next, taking the
permutation from 24 to 48 cycles. Do not paper over it with timing
constraints -- the same reasoning from Phase 1 applies: constraints change
what the tool checks, pipelining changes the actual circuit.

## Diagnosing a hardware failure
`host_sampler.py` checks A_hat and s_hat separately, which localises faults:

- **A_hat wrong, s_hat right** -> SHAKE-128 or the SampleNTT rejection loop
- **s_hat wrong, A_hat right** -> SHAKE-256, the CBD sampler, or the NTT
- **Both wrong** -> the shared Keccak permutation, or timing closure
- **No PING reply** -> CPU_RESET polarity (assumed active high)

## What this is not
Still not ML-KEM. This is KeyGen's inner loop for a single (i,j) matrix entry
and a single secret polynomial. Phase 4 remains: the basecase degree-2
multiplier (Algs 11-12), ByteEncode/Decode and Compress/Decompress (Algs 4-6),
the k x k matrix loops, and full KeyGen/Encaps/Decaps with the
Fujisaki-Okamoto transform (Algs 16-18), then NIST KAT validation.
