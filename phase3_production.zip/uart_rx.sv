// =============================================================================
// uart_rx.sv -- 8N1 UART receiver
// Samples the start bit, then samples each data bit at its midpoint.
// CLKS_PER_BIT = f_clk / baud  (e.g. 100e6 / 115200 = 868)
// =============================================================================
module uart_rx #(
  parameter integer CLKS_PER_BIT = 868
)(
  input  wire       clk,
  input  wire       rst_n,
  input  wire       rx,           // async serial in (already synchronized)
  output reg  [7:0] data,
  output reg        valid         // 1-cycle strobe when `data` is good
);
  localparam ST_IDLE  = 2'd0;
  localparam ST_START = 2'd1;
  localparam ST_DATA  = 2'd2;
  localparam ST_STOP  = 2'd3;

  reg [1:0]  state;
  reg [15:0] cnt;
  reg [2:0]  bit_idx;
  reg [7:0]  shreg;

  // 2-flop synchronizer for the async input
  reg rx_m, rx_s;
  always @(posedge clk) begin
    if (!rst_n) begin rx_m <= 1'b1; rx_s <= 1'b1; end
    else        begin rx_m <= rx;   rx_s <= rx_m;  end
  end

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= ST_IDLE; cnt <= 16'd0; bit_idx <= 3'd0;
      shreg <= 8'd0; data <= 8'd0; valid <= 1'b0;
    end else begin
      valid <= 1'b0;
      case (state)
        ST_IDLE: begin
          cnt <= 16'd0; bit_idx <= 3'd0;
          if (rx_s == 1'b0) state <= ST_START;   // falling edge = start bit
        end

        ST_START: begin
          // sample at the middle of the start bit to confirm it
          if (cnt == (CLKS_PER_BIT/2)) begin
            if (rx_s == 1'b0) begin cnt <= 16'd0; state <= ST_DATA; end
            else              state <= ST_IDLE;   // glitch, not a real start
          end else cnt <= cnt + 16'd1;
        end

        ST_DATA: begin
          if (cnt == (CLKS_PER_BIT-1)) begin
            cnt   <= 16'd0;
            shreg <= {rx_s, shreg[7:1]};          // LSB first
            if (bit_idx == 3'd7) begin bit_idx <= 3'd0; state <= ST_STOP; end
            else bit_idx <= bit_idx + 3'd1;
          end else cnt <= cnt + 16'd1;
        end

        ST_STOP: begin
          if (cnt == (CLKS_PER_BIT-1)) begin
            data  <= shreg;
            valid <= 1'b1;
            cnt   <= 16'd0;
            state <= ST_IDLE;
          end else cnt <= cnt + 16'd1;
        end
      endcase
    end
  end
endmodule : uart_rx
