// =============================================================================
// sampler_uart_core.sv -- UART command bridge for the Phase 3 FIPS 203
//                         sampling data path
// -----------------------------------------------------------------------------
// Same architecture as Phase 1 and 2: board-INDEPENDENT (plain clk/rst_n plus
// one UART RX and one TX pin), so the whole thing is simulatable. All KC705
// glue lives in kc705_sampler_top.sv.
//
// Wraps ml_kem_sampler_top, which implements the inner data path of
// FIPS 203 K-PKE.KeyGen for one matrix entry and one secret polynomial:
//
//   A_hat[i][j] = SampleNTT( SHAKE-128( rho || j || i ) )     Algorithm 7
//   s           = SamplePolyCBD_2( SHAKE-256( sigma || N ) )  Algorithm 8
//   s_hat       = NTT( s )                                    Algorithm 9
//
// COMMAND PROTOCOL (host -> FPGA), 8N1, LSB first:
//
//   0xA5                        PING                    -> 0x5A
//   0x50 <addr> <data>          write seed byte         -> 0x50
//                               addr 0..31  = rho
//                               addr 32..63 = sigma
//   0x51 <i> <j> <n>            set matrix i, j, PRF N  -> 0x51
//   0x52                        start the pipeline      -> 0x52
//   0x53                        status                  -> {5'b0,err,done,busy}
//   0x54 <idx>                  read A_hat[idx]         -> <lo> <hi>
//   0x55 <idx>                  read s_hat[idx]         -> <lo> <hi>
//
// Coefficients are 16-bit little-endian, matching the golden .hex convention
// used by every testbench in this project.
//
// Bit 2 of the status byte is ml_kem_sampler_top's sample_error, which flags
// SampleNTT exhausting its 672-byte SHAKE-128 stream before accepting 256
// coefficients. That is astronomically unlikely but is surfaced rather than
// hidden, since silently returning 256 wrong coefficients would be worse.
// =============================================================================
module sampler_uart_core #(
  parameter integer CLKS_PER_BIT = 868   // 100 MHz / 115200 baud
)(
  input  wire clk,
  input  wire rst_n,
  input  wire uart_rx_i,
  output wire uart_tx_o
);

  // ---------------------------------------------------------------------------
  // UART physical layer (identical modules to Phase 1 and 2)
  // ---------------------------------------------------------------------------
  wire [7:0] rx_data;
  wire       rx_valid;

  uart_rx #(.CLKS_PER_BIT(CLKS_PER_BIT)) u_rx (
    .clk(clk), .rst_n(rst_n), .rx(uart_rx_i),
    .data(rx_data), .valid(rx_valid)
  );

  reg        tx_send;
  reg  [7:0] tx_data;
  wire       tx_busy;

  uart_tx #(.CLKS_PER_BIT(CLKS_PER_BIT)) u_tx (
    .clk(clk), .rst_n(rst_n), .send(tx_send), .data(tx_data),
    .tx(uart_tx_o), .busy(tx_busy)
  );

  // ---------------------------------------------------------------------------
  // Phase 3 sampler pipeline
  // ---------------------------------------------------------------------------
  reg         smp_start;
  reg  [7:0]  mat_i, mat_j, prf_n;
  reg  [5:0]  seed_wr_addr;
  reg  [7:0]  seed_wr_data;
  reg         seed_wr_en;
  reg  [7:0]  a_rd_addr, s_rd_addr;
  wire [15:0] a_rd_data, s_rd_data;
  wire        smp_busy, smp_done, smp_err;

  ml_kem_sampler_top u_sampler (
    .clk(clk), .rst_n(rst_n), .start(smp_start),
    .mat_i(mat_i), .mat_j(mat_j), .prf_n(prf_n),
    .seed_wr_addr(seed_wr_addr), .seed_wr_data(seed_wr_data),
    .seed_wr_en(seed_wr_en),
    .a_rd_addr(a_rd_addr), .a_rd_data(a_rd_data),
    .s_rd_addr(s_rd_addr), .s_rd_data(s_rd_data),
    .busy(smp_busy), .done(smp_done), .sample_error(smp_err)
  );

  // ---------------------------------------------------------------------------
  // Command FSM
  // ---------------------------------------------------------------------------
  localparam [7:0] C_PING     = 8'hA5;
  localparam [7:0] PING_REPLY = 8'h5A;
  localparam [7:0] C_SEED     = 8'h50;
  localparam [7:0] C_IDX      = 8'h51;
  localparam [7:0] C_GO       = 8'h52;
  localparam [7:0] C_STAT     = 8'h53;
  localparam [7:0] C_RD_A     = 8'h54;
  localparam [7:0] C_RD_S     = 8'h55;

  localparam ST_CMD      = 5'd0;
  localparam ST_SEED_A   = 5'd1;   // seed: collect addr
  localparam ST_SEED_D   = 5'd2;   // seed: collect data, commit
  localparam ST_IDX_I    = 5'd3;   // indices: i
  localparam ST_IDX_J    = 5'd4;   // indices: j
  localparam ST_IDX_N    = 5'd5;   // indices: N
  localparam ST_RDA_A    = 5'd6;   // A_hat: collect index
  localparam ST_RDA_W    = 5'd7;   // A_hat: settle (rd_data is combinational)
  localparam ST_RDA_LO   = 5'd8;
  localparam ST_RDA_HI   = 5'd9;
  localparam ST_RDS_A    = 5'd10;  // s_hat: collect index
  localparam ST_RDS_W    = 5'd11;  // s_hat: settle
  localparam ST_RDS_LO   = 5'd12;
  localparam ST_RDS_HI   = 5'd13;
  localparam ST_REPLY    = 5'd14;
  localparam ST_TX_WAIT  = 5'd15;

  reg [4:0]  state;
  reg [4:0]  next_after_tx;
  reg [7:0]  pending_tx;
  reg [7:0]  addr_reg;
  reg [15:0] rd_latch;

  always @(posedge clk) begin
    if (!rst_n) begin
      state <= ST_CMD; next_after_tx <= ST_CMD;
      tx_send <= 1'b0; tx_data <= 8'd0; pending_tx <= 8'd0;
      addr_reg <= 8'd0; rd_latch <= 16'd0;
      smp_start <= 1'b0;
      mat_i <= 8'd0; mat_j <= 8'd0; prf_n <= 8'd0;
      seed_wr_addr <= 6'd0; seed_wr_data <= 8'd0; seed_wr_en <= 1'b0;
      a_rd_addr <= 8'd0; s_rd_addr <= 8'd0;
    end else begin
      tx_send    <= 1'b0;
      smp_start  <= 1'b0;
      seed_wr_en <= 1'b0;

      case (state)
        // -------------------------------------------------------------------
        ST_CMD: if (rx_valid) begin
          case (rx_data)
            C_SEED:  state <= ST_SEED_A;
            C_IDX:   state <= ST_IDX_I;
            C_RD_A:  state <= ST_RDA_A;
            C_RD_S:  state <= ST_RDS_A;

            C_GO: begin
              smp_start  <= 1'b1;
              pending_tx <= C_GO;
              state <= ST_REPLY;
            end

            C_STAT: begin
              pending_tx <= {5'd0, smp_err, smp_done, smp_busy};
              state <= ST_REPLY;
            end

            C_PING: begin
              pending_tx <= PING_REPLY;
              state <= ST_REPLY;
            end

            default: state <= ST_CMD;   // unknown byte: ignore and resync
          endcase
        end

        // ---- seed load (rho at 0..31, sigma at 32..63) ---------------------
        ST_SEED_A: if (rx_valid) begin
          addr_reg <= rx_data;
          state <= ST_SEED_D;
        end
        ST_SEED_D: if (rx_valid) begin
          seed_wr_addr <= addr_reg[5:0];
          seed_wr_data <= rx_data;
          seed_wr_en   <= 1'b1;
          pending_tx   <= C_SEED;
          state <= ST_REPLY;
        end

        // ---- matrix indices and PRF counter --------------------------------
        ST_IDX_I: if (rx_valid) begin mat_i <= rx_data; state <= ST_IDX_J; end
        ST_IDX_J: if (rx_valid) begin mat_j <= rx_data; state <= ST_IDX_N; end
        ST_IDX_N: if (rx_valid) begin
          prf_n      <= rx_data;
          pending_tx <= C_IDX;
          state <= ST_REPLY;
        end

        // ---- read A_hat ----------------------------------------------------
        ST_RDA_A: if (rx_valid) begin
          a_rd_addr <= rx_data;
          state <= ST_RDA_W;
        end
        ST_RDA_W: begin
          rd_latch <= a_rd_data;
          state <= ST_RDA_LO;
        end
        ST_RDA_LO: if (!tx_busy && !tx_send) begin
          tx_data <= rd_latch[7:0];
          tx_send <= 1'b1;
          next_after_tx <= ST_RDA_HI;
          state <= ST_TX_WAIT;
        end
        ST_RDA_HI: if (!tx_busy && !tx_send) begin
          tx_data <= rd_latch[15:8];
          tx_send <= 1'b1;
          next_after_tx <= ST_CMD;
          state <= ST_TX_WAIT;
        end

        // ---- read s_hat ----------------------------------------------------
        ST_RDS_A: if (rx_valid) begin
          s_rd_addr <= rx_data;
          state <= ST_RDS_W;
        end
        ST_RDS_W: begin
          rd_latch <= s_rd_data;
          state <= ST_RDS_LO;
        end
        ST_RDS_LO: if (!tx_busy && !tx_send) begin
          tx_data <= rd_latch[7:0];
          tx_send <= 1'b1;
          next_after_tx <= ST_RDS_HI;
          state <= ST_TX_WAIT;
        end
        ST_RDS_HI: if (!tx_busy && !tx_send) begin
          tx_data <= rd_latch[15:8];
          tx_send <= 1'b1;
          next_after_tx <= ST_CMD;
          state <= ST_TX_WAIT;
        end

        // ---- single-byte reply ---------------------------------------------
        ST_REPLY: if (!tx_busy && !tx_send) begin
          tx_data <= pending_tx;
          tx_send <= 1'b1;
          next_after_tx <= ST_CMD;
          state <= ST_TX_WAIT;
        end

        ST_TX_WAIT: begin
          if (tx_busy) state <= ST_TX_WAIT;
          else if (!tx_send) state <= next_after_tx;
        end

        default: state <= ST_CMD;
      endcase
    end
  end
endmodule : sampler_uart_core
